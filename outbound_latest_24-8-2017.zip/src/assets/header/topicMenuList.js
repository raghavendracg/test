var topicMenuList = [
    {
        "show": true,
        "id": "supv",
        "helpLink": "null",
        "newColumn": null,
        "label": "Supervision",
        "next": [
            {
                "show": true,
                "id": "supv_viewing",
                "helpLink": "null",
                "newColumn": null,
                "label": "Viewing",
                "next": [
                    {
                        "show": true,
                        "id": "supv_incoming_call",
                        "helpLink": "doc_spv.htm",
                        "newColumn": null,
                        "label": "Multichannel interactions",
                        "next": "supervisionIncomingCallSearch"
                    },
                    {
                        "show": true,
                        "id": "supv_outgoing_calls",
                        "helpLink": "doc_spv.htm",
                        "newColumn": null,
                        "label": "Outbound voice interactions",
                        "next": "supervisonOutgoingCallSearch"
                    }
                ]
            },
            {
                "show": true,
                "id": "bandeau_mngr",
                "helpLink": "null",
                "newColumn": null,
                "label": "Supervisor interface",
                "next": [
                    {
                        "show": true,
                        "id": "taskpanel_supv_tools",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0208",
                        "newColumn": null,
                        "label": "Agents management",
                        "next": "taskpanelSupervisorToolsSearch"
                    },
                    {
                        "show": true,
                        "id": "bandeau_mngr_message",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0208",
                        "newColumn": null,
                        "label": "Scrolling messages",
                        "next": "taskPanelSupervisorMessagePanel"
                    },
                    {
                        "show": true,
                        "id": "bandeau_mngr_campaign",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0207",
                        "newColumn": null,
                        "label": "Callbacks campaign",
                        "next": "taskPanelSupervisiorCampaignSearchForm"
                    },
                    {
                        "show": true,
                        "id": "bandeau_mngr_black_list",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0206",
                        "newColumn": null,
                        "label": "Blacklist",
                        "next": "blackListSearch"
                    }
                ]
            },
            {
                "show": true,
                "id": "config_superv",
                "helpLink": "null",
                "newColumn": null,
                "label": "Configuration",
                "next": [
                    {
                        "show": true,
                        "id": "conf_ihm_forecast",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0223",
                        "newColumn": null,
                        "label": "Forecasts",
                        "next": "forecastSearch"
                    },
                    {
                        "show": true,
                        "id": "config_superv_agt",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0221",
                        "newColumn": null,
                        "label": "Agents",
                        "next": "supervisionTableSearch?objectId=1"
                    },
                    {
                        "show": true,
                        "id": "config_superv_competences",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0221",
                        "newColumn": null,
                        "label": "Skills",
                        "next": "supervisionTableSearch?objectId=14"
                    },
                    {
                        "show": true,
                        "id": "config_superv_gpa",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0221",
                        "newColumn": null,
                        "label": "Agent groups",
                        "next": "supervisionTableSearch?objectId=4"
                    },
                    {
                        "show": true,
                        "id": "config_superv_gpt",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0221",
                        "newColumn": null,
                        "label": "Gates",
                        "next": "supervisionTableSearch?objectId=5"
                    },
                    {
                        "show": true,
                        "id": "config_superv_gatedetailbyddi",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0221",
                        "newColumn": null,
                        "label": "Gates monitoring - DDI details",
                        "next": "supervisionTableSearch?objectId=8"
                    },
                    {
                        "show": true,
                        "id": "config_superv_formule",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0224",
                        "newColumn": null,
                        "label": "Formulas",
                        "next": "supervisionFormulaSearch"
                    },
                    {
                        "show": true,
                        "id": "graphic_references",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0225",
                        "newColumn": null,
                        "label": "Graphic components",
                        "next": "supervisionGraphicComponentSearch"
                    },
                    {
                        "show": true,
                        "id": "console_search",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0226",
                        "newColumn": null,
                        "label": "Synthetic view",
                        "next": "supervisionConsoleSearch"
                    },
                    {
                        "show": true,
                        "id": "config_alerting",
                        "helpLink": "doc_spv.htm#LINK_ODIREF0220",
                        "newColumn": null,
                        "label": "Alerting",
                        "next": "alertSearch"
                    }
                ]
            }
        ]
    },
    {
        "show": true,
        "id": "stat",
        "helpLink": "null",
        "newColumn": null,
        "label": "Statistics",
        "next": [
            {
                "show": true,
                "id": "stat_viewing",
                "helpLink": "null",
                "newColumn": null,
                "label": "Viewing",
                "next": [
                    {
                        "show": true,
                        "id": "stat_incoming_call",
                        "helpLink": "doc_stats.htm",
                        "newColumn": null,
                        "label": "Multichannel interactions",
                        "next": "statisticIncomingCallSearch"
                    },
                    {
                        "show": true,
                        "id": "stat_outgoing_call",
                        "helpLink": "doc_stats.htm",
                        "newColumn": null,
                        "label": "Outbound voice interactions",
                        "next": "statisticOutgoingCallSearch"
                    },
                    {
                        "show": true,
                        "id": "stat_other_stats",
                        "helpLink": "doc_stats.htm",
                        "newColumn": null,
                        "label": "Other Statistics",
                        "next": "statisticOtherStatisticSearch"
                    }
                ]
            },
            {
                "show": true,
                "id": "config_stat",
                "helpLink": "null",
                "newColumn": null,
                "label": "Configuration",
                "next": [
                    {
                        "show": true,
                        "id": "config_stat_agt",
                        "helpLink": "doc_stats.htm#LINK_ODIREF0301",
                        "newColumn": null,
                        "label": "Agents",
                        "next": "statisticsSearch?objectTypeId=1"
                    },
                    {
                        "show": true,
                        "id": "config_stat_gpa",
                        "helpLink": "doc_stats.htm#LINK_ODIREF0301",
                        "newColumn": null,
                        "label": "Agent groups",
                        "next": "statisticsSearch?objectTypeId=4"
                    },
                    {
                        "show": true,
                        "id": "config_stat_gpt",
                        "helpLink": "doc_stats.htm#LINK_ODIREF0301",
                        "newColumn": null,
                        "label": "Gates",
                        "next": "statisticsSearch?objectTypeId=5"
                    },
                    {
                        "show": true,
                        "id": "config_stat_sda",
                        "helpLink": "doc_stats.htm#LINK_ODIREF0301",
                        "newColumn": null,
                        "label": "DDI",
                        "next": "statisticsSearch?objectTypeId=2"
                    },
                    {
                        "show": true,
                        "id": "config_subscription",
                        "helpLink": "doc_stats.htm#LINK_ODIREF0302",
                        "newColumn": null,
                        "label": "Subscriptions",
                        "next": "statisticSubscriptionSearch"
                    }
                ]
            }
        ]
    },
    {
        "show": true,
        "id": "config",
        "helpLink": "null",
        "newColumn": null,
        "label": "Configuration",
        "next": [
            {
                "show": true,
                "id": "config_cst",
                "helpLink": "null",
                "newColumn": null,
                "label": "Odigo configuration",
                "next": [
                    {
                        "show": true,
                        "id": "utilisateur",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Users",
                        "next": [
                            {
                                "show": true,
                                "id": "user_template",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0115",
                                "newColumn": null,
                                "label": "Templates",
                                "next": "userTemplateSearch"
                            },
                            {
                                "show": true,
                                "id": "user_config",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0116",
                                "newColumn": null,
                                "label": "User accounts",
                                "next": "userSearch"
                            }
                        ]
                    },
                    {
                        "show": true,
                        "id": "config_cst_agent",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Agent groups",
                        "next": [
                            {
                                "show": true,
                                "id": "config_agent",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0110",
                                "newColumn": null,
                                "label": "Configuration",
                                "next": "agentGroupSearch"
                            },
                            {
                                "show": true,
                                "id": "config_group_agent_gate",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0111",
                                "newColumn": null,
                                "label": "Organizations",
                                "next": "agentGroupTreeSearch"
                            }
                        ]
                    },
                    {
                        "show": true,
                        "id": "config_group",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Gates",
                        "next": [
                            {
                                "show": true,
                                "id": "config_group_search",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0112",
                                "newColumn": null,
                                "label": "Configuration",
                                "next": "gateSearch"
                            },
                            {
                                "show": true,
                                "id": "config_group_create_group",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0113",
                                "newColumn": null,
                                "label": "Organizations",
                                "next": "gateTreeSearch"
                            },
                            {
                                "show": true,
                                "id": "config_skill_repartition",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0114",
                                "newColumn": null,
                                "label": "Skill dispatch",
                                "next": "gateSkillDispatchSearch"
                            }
                        ]
                    },
                    {
                        "show": true,
                        "id": "config_refrentiel",
                        "helpLink": "null",
                        "newColumn": true,
                        "label": "Repository",
                        "next": [
                            {
                                "show": true,
                                "id": "config_channel",
                                "helpLink": "doc_conf.htm#CHANNEL_TEMPLATE",
                                "newColumn": null,
                                "label": "Channels",
                                "next": "channelSearch"
                            },
                            {
                                "show": true,
                                "id": "config_ref_cal",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0131",
                                "newColumn": null,
                                "label": "Calendars",
                                "next": "calendarSearch"
                            },
                            {
                                "show": true,
                                "id": "motif_search",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0133",
                                "newColumn": null,
                                "label": "Call reasons",
                                "next": "reasonForCallSearch"
                            },
                            {
                                "show": true,
                                "id": "config_codification",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0132",
                                "newColumn": null,
                                "label": "Call codifications",
                                "next": "codificationSearch"
                            },
                            {
                                "show": true,
                                "id": "config_competence",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0137",
                                "newColumn": null,
                                "label": "Skills",
                                "next": "skillSearch"
                            },
                            {
                                "show": true,
                                "id": "config_common_queue",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0134",
                                "newColumn": null,
                                "label": "Common queues",
                                "next": "commonQueueSearch"
                            },
                            {
                                "show": true,
                                "id": "config_annuaire",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0136",
                                "newColumn": null,
                                "label": "Mini-Directories",
                                "next": "miniDirectorySearch"
                            },
                            {
                                "show": true,
                                "id": "pause_edition",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0130",
                                "newColumn": null,
                                "label": "Activities",
                                "next": "otherActivitySearch"
                            },
                            {
                                "show": true,
                                "id": "config_sda",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0135",
                                "newColumn": null,
                                "label": "DDI",
                                "next": "ddiSearch"
                            },
                            {
                                "show": true,
                                "id": "config_message",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0138",
                                "newColumn": null,
                                "label": "SMS templates",
                                "next": "smsTemplateSearch"
                            },
                            {
                                "show": true,
                                "id": "config_dimeloSSOUrl",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Digital Configuration",
                                "next": "https://bridges-it.prosodie.com/dimelo-sso"
                            }
                        ]
                    }
                ]
            },
            {
                "show": true,
                "id": "config_advncedSettings",
                "helpLink": "null",
                "newColumn": null,
                "label": "Advanced settings",
                "next": [
                    {
                        "show": true,
                        "id": "admin_js",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Javascript",
                        "next": [
                            {
                                "show": true,
                                "id": "admin_js_bandeau",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0102",
                                "newColumn": null,
                                "label": "Javascript code",
                                "next": "javascriptSearch"
                            },
                            {
                                "show": true,
                                "id": "action_search",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0103",
                                "newColumn": null,
                                "label": "Actions",
                                "next": "actionButtonSearch"
                            },
                            {
                                "show": true,
                                "id": "button_search",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0100",
                                "newColumn": null,
                                "label": "Buttons",
                                "next": "buttonSearch"
                            }
                        ]
                    },
                    {
                        "show": true,
                        "id": "admin_params",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Administration",
                        "next": [
                            {
                                "show": true,
                                "id": "admin_gene",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "General parameters",
                                "next": "generalParameterEdit"
                            },
                            {
                                "show": true,
                                "id": "admin_ws",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Web services",
                                "next": "administrationParameterWsEdit"
                            },
                            {
                                "show": true,
                                "id": "admin_unified_tickets",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Unified tickets",
                                "next": "configurationUnifiedTicketSearch"
                            },
                            {
                                "show": true,
                                "id": "cpt_svi1",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "IVR counters / Other counters",
                                "next": "statisticSviSearch"
                            },
                            {
                                "show": true,
                                "id": "admin_exploit",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Operating",
                                "next": "administrationOperating"
                            },
                            {
                                "show": true,
                                "id": "admin_multilangauge",
                                "helpLink": "doc_conf.htm#CFU_DOC",
                                "newColumn": null,
                                "label": "MultiLanguage",
                                "next": "multilanguageSearchForm"
                            },
                            {
                                "show": true,
                                "id": "admin_customer_interactions",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Customer Interactions",
                                "next": "customFieldSearch"
                            },
                            {
                                "show": true,
                                "id": "admin_partnersync",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Partner Synchronization",
                                "next": "partnerSyncInformation"
                            }
                        ]
                    }
                ]
            },
            {
                "show": true,
                "id": "config_import",
                "helpLink": "null",
                "newColumn": null,
                "label": "Import/Export",
                "next": [
                    {
                        "show": true,
                        "id": "config_import",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Export",
                        "next": [
                            {
                                "show": true,
                                "id": "config_import_export_export",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "Export",
                                "next": "pendingModificationsSearch?page=0"
                            },
                            {
                                "show": true,
                                "id": "config_admin_export",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "Administrator export",
                                "next": "pendingModificationsSearch?page=1"
                            },
                            {
                                "show": true,
                                "id": "config_admin_export_full",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "Full export",
                                "next": "pendingModificationsSearch?page=2"
                            },
                            {
                                "show": true,
                                "id": "config_import_export_histo",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "History",
                                "next": "historySearch"
                            },
                            {
                                "show": true,
                                "id": "config_import_export_modif",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "Pending modifications",
                                "next": "pendingModificationsSearch?page=3"
                            },
                            {
                                "show": true,
                                "id": "config_admin_modifs",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "Administrator modifications",
                                "next": "pendingModificationsSearch?page=4"
                            },
                            {
                                "show": true,
                                "id": "config_admin_modifs_full",
                                "helpLink": "doc_conf.htm#LINK_ODIREF0120",
                                "newColumn": null,
                                "label": "All modifications",
                                "next": "pendingModificationsSearch?page=5"
                            }
                        ]
                    },
                    {
                        "show": true,
                        "id": "config_import_import",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Import",
                        "next": [
                            {
                                "show": true,
                                "id": "config_import_import",
                                "helpLink": "null",
                                "newColumn": null,
                                "label": "Import",
                                "next": "importSearch"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    {
        "show": true,
        "id": "config_outbound",
        "helpLink": "null",
        "newColumn": null,
        "label": "Outbound Campaign",
        "next": null
    },
    {
        "show": true,
        "id": "help_links",
        "helpLink": "null",
        "newColumn": null,
        "label": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAYCAYAAAD6S912AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyZpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDE0IDc5LjE1Njc5NywgMjAxNC8wOC8yMC0wOTo1MzowMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTQgKFdpbmRvd3MpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkEzNEQxNkY5Q0Q4MjExRTRBMjIzQTJCNDM0NTNFMjc2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkEzNEQxNkZBQ0Q4MjExRTRBMjIzQTJCNDM0NTNFMjc2Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QTM0RDE2RjdDRDgyMTFFNEEyMjNBMkI0MzQ1M0UyNzYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QTM0RDE2RjhDRDgyMTFFNEEyMjNBMkI0MzQ1M0UyNzYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4sRqVxAAABaUlEQVR42tzUzysEYRjA8Xe1SYhS2pQDK9qLUv4C/4C4yW2LA//C5ubowEkpOUvJ1c1JkmxqN20kP1JS2pCSmn1933pejfHONO9y8tSnaZ6dfeadeZ55M1rrMaXUJjqVf1xiFs82kaHgBUdjy7NYBqs4xpRNZkUJ5SZWOIyZcKIFb+hXzUUP6tGCfxr/v2AvcuFEVo7ao0hOrn+UUQtkhLRdYTfuUxSak9G6xR2O0Irit+FksM84vmJb7rKBD0xiALvoQjXmRoO4/jqjYB4HqKCGG5QQoIpROY+LNShLhU/EQuhim9tPKLgT/r+ry+soYA99kjtNeLdlV5ejUcM02qWDhYSCI9GmpJnVIOF3HZ7nNIPdkM7HxYrvCu3e13Dk67LjeH965q7zjvzib77lF0fu4cejpHxk0+0ntEXyVxjyWeGEvPRzRzETeVSwjHH76cVZ0v5RjHtks/JD6eB7iu3NTEEHTj4FGAB35SEsESAZ3gAAAABJRU5ErkJggg==",
        "next": [
            {
                "show": true,
                "id": "help_account",
                "helpLink": "null",
                "newColumn": null,
                "label": "Help and Account",
                "next": [
                    {
                        "show": true,
                        "id": "help_contact",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Help and contact",
                        "next": "help"
                    }
                ]
            },
            {
                "show": true,
                "id": "other_links_level1",
                "helpLink": "null",
                "newColumn": null,
                "label": "Others links",
                "next": [
                    {
                        "show": false,
                        "id": "other_links_level2",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Others links",
                        "next": ""
                    },
                    {
                        "show": true,
                        "id": "86",
                        "helpLink": "null",
                        "newColumn": null,
                        "label": "Maroc - Console de supervision",
                        "next": "javascript:actionCustomizedJavascript[0]()"
                    }
                ]
            }
        ]
    }
]