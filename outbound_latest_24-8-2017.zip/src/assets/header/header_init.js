 $(document).ready(function(){
        Header.init2({
            "div": "header",
            "topics": topicMenuList,
            "product": 1,
            "checkPortalContext": "1",
            "notificationDuration": 5000
        });
    });