 /* =================================================================================
 * ODIGO Suite's Portal - Header JavaScript Library v1.2 (Default)
 *
 * $LastChangedDate: 2017-04-21 12:36:07 +0200 (Fri, 21 Apr 2017) $
 * $LastChangedRevision: 3535 $
 * Copyright 2014, Prosodie
 
 ================================================================================= */
/* Define console object for IE */
if (typeof console === 'undefined' || console.notdefined == true) {
   console = { log: function() {}, info: function() {}, warn: function() {}, error: function() {}, table: function() {},
 notdefined: true }
}
    
var Header = {

    /* ========================
     * Global Public Variables
     * ======================== */
    "logo" : {"title": "null","image":"odigo/img/odigo.png","odigo_url":"odigo/index.jsp"},
    "customers":{"organizationName":"Prosodie","uid":"prosodie","labeledURI":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEASABIAAD/4RF6RXhpZgAATU0AKgAAAAgACgEAAAMAAAABAMgAAAEBAAMAAAABAF0AAAECAAMAAAADAAAIkgEGAAMAAAABAAIAAAESAAMAAAABAAEAAAEVAAMAAAABAAMAAAExAAIAAAAeAAAImAEyAAIAAAAUAAAItodpAAQAAAABAAAIyuocAAcAAAgMAAAAhgAAAAAc6gAAAAgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAgACEFkb2JlIFBob3Rvc2hvcCBDUzUgTWFjaW50b3NoADIwMTM6MDM6MTIgMTc6NDM6MjIAAAmQAAAHAAAABDAyMjGQAwACAAAAFAAAEUiQBAACAAAAFAAAEVySkQACAAAAAzAwAACSkgACAAAAAzAwAACgAQADAAAAAf//AACgAgAEAAAAAQAAAMWgAwAEAAAAAQAAAHHqHAAHAAAIDAAACTwAAAAAHOoAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyMDEzOjAzOjEyIDE3OjM1OjQxADIwMTM6MDM6MTIgMTc6MzU6NDEAAAD/4QncaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLwA8P3hwYWNrZXQgYmVnaW49J++7vycgaWQ9J1c1TTBNcENlaGlIenJlU3pOVGN6a2M5ZCc/Pg0KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyI+PHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj48cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0idXVpZDpmYWY1YmRkNS1iYTNkLTExZGEtYWQzMS1kMzNkNzUxODJmMWIiIHhtbG5zOnhtcD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wLyI+PHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ1M1IE1hY2ludG9zaDwveG1wOkNyZWF0b3JUb29sPjx4bXA6Q3JlYXRlRGF0ZT4yMDEzLTAzLTEyVDE3OjM1OjQxPC94bXA6Q3JlYXRlRGF0ZT48L3JkZjpEZXNjcmlwdGlvbj48L3JkZjpSREY+PC94OnhtcG1ldGE+DQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw/eHBhY2tldCBlbmQ9J3cnPz7/2wBDAAMCAgICAgMCAgIDAwMDBAYEBAQEBAgGBgUGCQgKCgkICQkKDA8MCgsOCwkJDRENDg8QEBEQCgwSExIQEw8QEBD/2wBDAQMDAwQDBAgEBAgQCwkLEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBD/wAARCAA8AGgDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD7N8M/th6b44+JHjL4Y+BPg/411/U/At5cWeqNbzaXCrGKd4C8X2i7j3KXjbGcHGMgdK6r4Y/tPfC/4peK9Q+HunzaroXjHSgzXnhzXrFrK/jC8khSSkmAQ37t2+Uq33SCfk79k3xNp/hH9rT9pXXNSs9WuoIta1BTFpelXOo3DMdWuANsFtG8je524Hciu0+HfwL+JvxS/bHm/aw8UeE7rwJ4a07jSNN1FkXVNR22TWivNEhPkqQzuQ5DABECsCXH0eJy/C0pVIy91KCad95NJ8tnve/TbqeVRxNacYyWrcmmuyu9fL5n2xmjNfA/7K/7Q37XX7VUmu6fYeLvA/hWx8OtBJeasfDsl3cu0wfy4Y4DcLGVxDIWZiCMjG7Py+k+Dv2kfid8dP2hfFfwf+GMmi+H/C/gRZYdV1+706S8ury7im8lkhj81I4UaQSbdwkO2Etkbwo4a2T16E505NXgry1ei0tfTrfRK7OmnjqdSMZJP3tF5n1hSV8seA/2nviDov7TWr/su/FzTNK1K/8AszXXh7WtFtpLX7eq2xudk0EkrhWMQkG5WCh4iMEMGHkXwX/a78bfHbVNas/G37SWhfB3XI7z7Lpvh9/Ddubdk4ALXN65LzbyyGING2VyBg4Ujk2JcZT05Uoyvq9JbOyTfR9NOonj6Wi6ttfNb7ux+gmaM188/Hn47+Jv2W/2frfxd4w1LTfGfi+5uU0uyuILI6faXd1IJJEkaFZJCiJDGzMFf5ymAU3gryfi/wCIX7Ungr9nG2/aJk8WeFr/AFWPTbXXdR8MS6CyWUVnPsLRRyrP53mRJICWZ2DbGAA4rKll1SrGM00lKXLG99X5abebsaTxUINxad0rvyX9dj6zryT9oj9pLwf+zbo+ia14w0PXNTh12/OnwLpUcLskmwtucSyIAuB2JPtXlfiT9vPQ9N+BvgD4k6D4Ju9S8U/EqaXT9D8OfaQo+2QzfZ598+3HlrMVVSAGk8yP5VyxTxv/AIKHWnxSt/hf4BuPit4g8O3+o3XiJCLTQdNmtrWzYW8m9A800kk+SV+ciP7nCDJFdeAymUsVCni1aMnJW6vl3tbs+u3YwxONUaMpUXdpJ/efcXj74t/D34Xy6PD4+8T2+jvr939h00SxyN9onyBsGxTg/MvJwOa7AGvlT9tf4zeKvhR4q+Emm+HdM0C7h8Ta3PbXZ1TTVumjVZLRQ0JJHltiZ+R7elaXx2/aQ8c6L8evBn7MnwfsNIXxN4ojF5f6xq0MlxBptmRKzGOBHj82VY4JZMM4XhFwd+5OaGW1KtKnOC+JSd29LRer20/G/Q0eLhCc4y6WXzZ9NUV8m65+0B8VPhZ+1V4M+Aeoaxp3j7S/GFrHNcNHpy22p6UzGVWdvKfyzEBEZSGQMEDc/KCxXLiMNPDKDntJXVu23WzN6VWNbmUejsyj+yr8E/in8P8A9pz43ePfGXhGXTdA8V6pez6NeNdW8gu45NRmlUhI5GdMxsrfOq9fXivr18baxNa8YaLojSRzPNNPFjzIbeIyMmRkBj91CQcjeRkdK8R+Kn7SGtaO1p/wiGkiAWtws139taMtcRr1hAQuEDD+MMWGBgV3exxWc1lKMVeyXZaKy3PMxGYYPJ6L9pLRX83qzzP/AIJsfBj4pfCGx+IVt8TPBV94ffU59NNmLpoz5/lrcCQrsZhxvT8xV74cfBX4r/s0/tNeO/Hug+Dbvxp4A+IT3F250m6tVv8ATbmSczqskVxJFvRWkmQFGYlWRjggrXo3h/8AbY+Dt88Vv4jXWfDtw4AdrqzM0Kv3AeAuSM/xMq++K7D4xfHTRfhz8JW+JPh2O28Sz6lJbWPh61tbpdmp31zII4I1kHG3JLMRyFR8DOBXbiqmZfWpuvRs61otWdna1rO/S19zPBYjL8VQi8NVUlDXRq69V/wDwnwh8Efit4r/AGtNY/a28feDbrw7pOhWU0Xh3w6bq1n1W+xZNbL5gikaFNyvMwUygh3Rc7QXqL4yaf8ABv426VdX3jn9jH4snxXJGwW4sfDaWt95/l7ELXsMvkyqvGPNaRBgHYele+61b/HHQdF0XVtP8R6Prmqtqmlwa5p40cpZmzkuYorySzxMJomjieSVWlkmGIyCvIx10fxE+H8l9d6VH448PPfWCyPd2y6nAZbdY+JDIm7cgU43ZAx3rlePq88ay15Uox5XJcqj07633e/c7Vhocrg9Lu7vZ3bPgvwP+xL8dPGv7Hd/8MfH94NG16z8SJ4g8K6VqF6Jo7SNLcxPBI0ZcQJL5srBEJCthiAWcV6z420/9pDxt+y3b/AW3+Bep2niy90m08Palqt7rOl/2VHDEI0luleO5aVvMRDhBEGUu3XYN/0/ZeP/AANqOpW2j6f4y0K6vr2Iz21rDqUMk00YBJdEDFmXAJyBjg1LN4y8HWt8+mXHijR4ryJwklu99EsqscYUoWyCcjgjuKdTNsVWqc86abUudKz0fye2nXqSsJQpRspWuuXdanxf4/8A2G/iLo3wl+DMHw11jSdX8Y/CG7m1KS1u2MFvqU012l66xSHGAk6bVDhdyMSWQgA7P7UXw7+NX7V2k+BPCel/B3V/Bkul6r9v1m917U9OeztAY9jLG1tcSyz4ySCI1yAM7cnb9djxd4Ve6ubFfEmlm5sVZ7qEXke+BV+8ZFzlAMjJOOtJD4r8K3N1FY2/iLS5bmeE3EUKXkZeSLGfMVQclcfxDilHNsWpxqSinKLk02npzavbS13df5A8NhmnBSsnZWuum3+R8xftxfBn4nfFjxZ8HtR+HfhOXWbfw1rc93qrpdW8P2aJpbRgxEsiluIpOFyfl9xmT9pL9mvx9rXxy8K/tKfCbT9I1/VNFtTpms+GdVnWCPVLIrNG6xyOpjDvDcTRESfKAVb5sFW998TfEbTdN8Nya94VXT/EsyXcVmttbavbRB3d1DL5sjbAyoxfaTkge+a2H8a+D40haTxTo6i4m+zQk30QEkvyjy1+b5my6/KOfmX1FTSx2KoU6cYxVoqUbd1LWSkr366beWwpQw1WpO8tXyv7tE09unn57nm3wl07wtoetKvhz9lG6+HF3fxFL/UIdN0O3iXAL7JJLK5aSVSwAG1WGSCQvJBXe6R4uutU8aax4XTR41stKt4JF1BNQhk82STdujMCkyRldvVgM849yvOxDlKd5Kzsut/Pu/8AgHZQcZR93XVra22nY+dfi1J8QPBesava3Gk6neade6hPfWd9b27ywukzbxGzIDsZM+XhsEhARwRjwbx1qHimxh+1eILCbT0kw3lXCFJsHlS0Z+ZcgbhuAyCGHykE/b+ofFWNbprCGx094J7rULGCZr67h8x7Qlbj5ltSqlW+XIcgvlVZmGK8pOj/AAN8WWYvH8D6FqdvKq3XnSeINUcSiS8NmJC5g+ctcKyZJJJG7lTur63K83+rRj7ajt1Vtfvas/60Pg864dnjpS+r1nZ9GnZfNRd/63PjjV/B/jjUJbVbDwbrV7HqKLLZzWdjJcRXSt3ieNSr9wdpJUghsEED6Ub9nf4pw/sn6Xp8ely3PjDwz4ttfHmlaE8yqz/Z5VJsySdqs8fnOAMfO4U4JY17J4Sh8M/CW3mi8H+C9N0q0u7a4v5Y4tc1Ga2EVuiPLKVa3aNGCunOAzZAG7bgdPZfFe71FzHY6Xo07LqcujuI9TuCYruORo2jkH2T5BvXaHbCHcmGO9Nxmef4nGKMaVNKMZc13bW3zdl31+46Mj4cw2VSdSpNuTVrJOyv8lf7l8yjrnx80H+xdLm8Habq2ta3qmo2FmuiJpVyt7aLNcRpO93CUDWixRNI7NPsUbOpyAfmPQZNQs/CX7O8mi6RqminQvG/navoOn6XdeR4YhmjvlmhuXn8y6WQ+cys0kuxwxYIitGK+rb34n6lpurR6Hf6HpkF5Nex6dGrX11se4e3e4VFk+x7DiKN2LA7V24YgkA5eqfGSaC1khT/AIR3S7xtNi1KNtRvrpRBbyypDHPLE9tGyp5kiA7iuM5JUAkeJhpyoLlhT3/vLZprt5+vydj6etOFR3lJ6f3X3TPl34aQnxR+x38GvAPgfTLmDxuviXSNUs1a3eRrXytQM0upM4BAtxbiQGTO0bvI+/8Au69A0DWdDvF0T4ZWfxA0nTNT8NeKNXvLC9vbiaLUdQupZLxIoyjRCMea9zlmEr71VflzIVj7T4CXl18Pfh/pXwf0680XXI9Et7a2s5WnurSRre4iE0G4tblXYq5YspXaGRWVT1XSNctU8C6H4Z+2WN94Xs9PivLCJp5vOlsrJVlQSsLL7nlxoybUR5FTcjOMk+k8V79Rcujk5J3X2ubXVbWekXbd6nk4mg6vs+XdRs/dfRxdt1bVfEr7bDPAWj6SPA3w+s9Wk1PSNa8FSefNYRacY7i2nWKWO6+0M2f3Eu+Ri4x5hZChYkA8dpOjx2vwJ+DOi3Wm3yXNv4ssLnW4TZzCWOBUmSf7QNu4IsMkcTbuPLIX7vFe36h8VrnSrXTLzUNL0iGHVbSW9tHbUro74Y4GncnFp8h8pHba+GbYwAJUgK/xUuIr4aa2k6SLlpLWJV/tC6wXuJpoYRu+x7fmkgmXrxsydoIJ5Vj693Lk0b5viX97T0vJj/syhyqPO9I8vwv+5r62gl2PJ/ivmfW/ivHZafeytqUnhD7N5NlK/wBpktrwm4KlVw5jQLuIzgAZ4pzWNndfDn4+zf2bdzXuvatqIso2s5Wa7hNsn2YxKVy4Mhl2lQeQfSvSo/jdbybdlvonzi5cA6ldKStvCk8jYNp0EMsUgPR0dWTcCCb+l/FC+1pUfTdF0meN4reVX/tC6VMTkiIFmtAA5xyhO4AgsACCbjjq0IRh7Pbl+0vs8i/HkXzYpZbRnVlN1N1L7D+05v8AD2j+4wfh1fJefG/xPqSrcmC98M6JDDPJbyKkssTXRlQMygFl8xcjORuFFdF4F+LWm+N7yxjsf7Ne31G3kuLea1uriXcFZl5D2yBMlJcbmBby32htrbSvHxspTq3lGzSS77K36Ht4CnGlR5Yyvq3tbd3/AFOo/wCEF8H/AGhLr/hG9O82Oa5uEb7OnyyXI/0hhxwZer4+8SSck5qGf4deBLqOSKbwjpLJKs6sv2OMD99cC5mIAGAXuAJmI5aRVc5YAjo6K5ueS6nZyxfQy5PC/h2ZZ1m0WzkW5jlimVoFIdJFVJFIIxtZUQEdCFGaryeCPB8rBpPDOmEjUF1bi1QZvVIK3BwOZQQp3nnKrzwK3KKXNLuHLHsZbeGfD7SW0zaRaGSzmW4t5PKXfHIsZiV1bGQRGzJn+6xHQ1Xt/BPhG2WGOHw3pyrBDFbRD7Mh2RRurxoCRkKrojKOgKqR0FblFPnl3Dlj2MG18CeDrGc3Vj4a022mP2b95Daxo3+jrsg5A/gUBV9FAA4ptt8P/BNnHYw2vhbTIo9MWVbNEtUC26yqVkVABhQVZlwONpI6cV0FFHPJ9Q5Y9jIvvCPhnVJIJtT0Gxu2tUljh863VxGssflyAAjADJ8h9VJHQkVF/wAIR4S8mOA+HrApEtsqgwL0t5GkgBOMnY7u656MxI5JNblFHNLuPlXY5tfhv4BRo5F8H6OGhNwY2+xR5Tz0Ec2DjgPGqoR3VVXooAuWng/wvp7KbHw/p9uEhgt0WK2RVSKEkwoABgBCTtA+7njFbFFDnJ7sXLHsYdj4H8H6ZeW+oab4Y0u1uLWSeWGSG0jjMbzO7yuNoGGdpJGJ6kyOf4myVuUUnJy3Gklsf//Z"},
    "user" :{"uid":"sadmin","userName":"Super Admin","role":"SuperAdmin","odigoemail":"sadmin@prosodie.com"},
    "products" : [{"uid" :"portal","commonName" :"Odigo Suite Portal","labeledURI" :"https:\/\/portal-it.prosodie.com\/portal\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Portal","label" :"Odigo Suite Portal","active" :"true"},{"uid" :"IVR_Designer","commonName" :"IVRDesignerIT","labeledURI" :"https:\/\/ivr-designer-it.prosodie.com\/ivr2\/index.html","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"IVRDesignerIT","active" :"true"},{"uid" :"routing","commonName" :"Odigo Routing","labeledURI" :"http:\/\/odigo.prosodie.com\/prosodie-us","odigoIndicators" :null,"openNewWindow" :"true","productType" :"Routing","label" :"Odigo Routing","active" :"true"},{"uid" :"easyrecord","commonName" :"Recording","labeledURI" :"https:\/\/recorder-it.prosodie.com\/odigorecorder\/","odigoIndicators" :{"url" :"https://recorder-it.prosodie.com/odigorecorder/EntryPoint?serviceName=IndicatorConfiguratorHandler","wspi" :"com.prosodie.odigo.suite.webservices.kpi.easyrecord.EasyRecordKPIWebServicesProvider"},"openNewWindow" :"false","productType" :"Record","label" :"Recording","active" :"true"},{"uid" :"pcm_frontoffice","commonName" :"PCM FrontOffice","labeledURI" :"https:\/\/pcsapp1int.recette1.prosodie.com\/pcsmutualfrontoffice\/web\/sommaire.faces","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"PCM FrontOffice","active" :"true"},{"uid" :"pcm_ihmsimplifiee","commonName" :"PCM IHM simplifi\u00E9e","labeledURI" :"https:\/\/pcsapp1int.recette1.prosodie.com\/pcsmutualIHMSimple\/web\/main.faces","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"PCM IHM simplifi\u00E9e","active" :"true"},{"uid" :"odigoACD_janos_odi","commonName" :"Odigo ODI","labeledURI" :"https:\/\/recette1.prosodie.com\/odi\/","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ODI","active" :"true"},{"uid" :"websds","commonName" :"WebSDS","labeledURI" :"https:\/\/my.prosodie.com\/arsys\/forms\/sds\/","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"WebSDS","active" :"true"},{"uid" :"smart_assistant","commonName" :"Smart Assistant","labeledURI" :"https:\/\/assistant-adm.prosodie.com\/user\/connection","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Smart Assistant","active" :"true"},{"uid" :"odigoACD_ppr2_recette_interne1","commonName" :"Odigo PPR2 interne1","labeledURI" :"https:\/\/ppr2odigo.prosodie.com\/recette-interne1\/","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PPR2 interne1","active" :"true"},{"uid" :"ivrdesigner_dev","commonName" :"IVRDesignerDEV","labeledURI" :"https:\/\/odigoivr-recette1.prosodie.com\/ivr","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"IVRDesignerDEV","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esa","commonName" :"Odigo ACD esa (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esa\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"Routing","label" :"Odigo ACD esa (bodiweb01pdx)","active" :"true"},{"uid" :"dev","commonName" :"Dev","labeledURI" :"https:\/\/recette1.prosodie.com\/odi\/","odigoIndicators" :{"url" :"https://recorder-it.prosodie.com/odigorecorder/EntryPoint?serviceName=IndicatorConfiguratorHandler","wspi" :"com.prosodie.odigo.suite.webservices.kpi.easyrecord.EasyRecordKPIWebServicesProvider"},"openNewWindow" :"true","productType" :"null","label" :"Dev","active" :"true"},{"uid" :"webrtc_localhost","commonName" :"WebRTC-localhost","labeledURI" :"http:\/\/localhost:8080\/webrtc-admin\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"WebRTC-localhost","active" :"true"},{"uid" :"odigo_uwv_integration","commonName" :"Routing [INT]","labeledURI" :"https:\/\/ppr3odigo.prosodie.com\/uwv-integration","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Routing [INT]","active" :"true"},{"uid" :"odigo_uwv_sandbox","commonName" :"Routing [SBOX]","labeledURI" :"https:\/\/ppr3odigo.prosodie.com\/uwv-sandbox","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Routing [SBOX]","active" :"true"},{"uid" :"odigo_uwv_uat","commonName" :"Routing [UAT]","labeledURI" :"https:\/\/ppr3odigo.prosodie.com\/uwv-uat","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Routing [UAT]","active" :"true"},{"uid" :"basic_call_routing","commonName" :"Basic Call routing","labeledURI" :"https:\/\/ivr-designer-it.prosodie.com\/bcr\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Basic Call Routing","label" :"Basic Call routing","active" :"true"},{"uid" :"pcm_ui_2.4_local","commonName" :"PCM New UI - Local","labeledURI" :"http:\/\/localhost:8080\/pcm\/ui\/service\/web\/home","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"PCM New UI - Local","active" :"true"},{"uid" :"pcm_ui_2.4_integ","commonName" :"PCM New UI - Integ","labeledURI" :"https:\/\/pcsapp1int.prosodie.com\/pcm\/ui\/service\/web\/home","odigoIndicators" :null,"openNewWindow" :"false","productType" :"PCM","label" :"PCM New UI - Integ","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_fra","commonName" :"Odigo ACD fra (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/fra\/ui\/service\/acdSearch","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD fra (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esb","commonName" :"Odigo ACD esb (bodiweb01pdx)","labeledURI" :"http:\/\/routing-it.prosodie.com\/esb\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esb (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esd","commonName" :"Odigo ACD esd (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esd\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esd (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_ese","commonName" :"Odigo ACD ese (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/ese\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ese (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esf","commonName" :"Odigo ACD esf (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esf\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esf (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esg","commonName" :"Odigo ACD esg (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esg\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esg (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esh","commonName" :"Odigo ACD esh (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esh\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esh (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esi","commonName" :"Odigo ACD esi (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esi\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esi (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esj","commonName" :"Odigo ACD esj (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esj\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esj (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esk","commonName" :"Odigo ACD esk (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esk\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esk (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esl","commonName" :"Odigo ACD esl (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esl\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esl (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_ess","commonName" :"Odigo ACD ess (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/ess\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ess (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esm","commonName" :"Odigo ACD esm (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esm\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esm (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_esn","commonName" :"Odigo ACD esn (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esn\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esn (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_localhost_esn","commonName" :"Odigo ACD ESN","labeledURI" :"http:\/\/localhost:8080\/esn\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ESN","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_dmi","commonName" :"Odigo ACD esa (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esa\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD esa (bodiweb01pdx)","active" :"true"},{"uid" :"odigoACD_bodiweb01pdx_ung","commonName" :"Odigo ACD ung (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/ung\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ung (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_est","commonName" :"Odigo ACD est (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/est\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD est (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_vnr04","commonName" :"Odigo ACD vnr04 (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/vnr04\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD vnr04 (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_vnr05","commonName" :"Odigo ACD vnr05 (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/vnr05\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD vnr05 (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_eso","commonName" :"Odigo ACD eso (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/eso\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD eso (bodiweb01pdx)","active" :"true"},{"uid" :"odigo-analytics-dev","commonName" :"Odigo Analytics Dev","labeledURI" :"https:\/\/odigo-analytics-dev.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo Analytics Dev","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_recette-interne2","commonName" :"Odigo ACD recette-interne2 (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/recette-interne2\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD recette-interne2 (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_recette-interne1","commonName" :"Odigo ACD recette-interne1 (bodiweb01pdx)","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/recette-interne1\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD recette-interne1 (bodiweb01pdx)","active" :"true"},{"uid" :"sso_example","commonName" :"SSO Example","labeledURI" :"https:\/\/localhost:8443\/sso-example","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"SSO Example","active" :"true"},{"uid" :"odigo_paas_local","commonName" :"Odigo PaaS Local","labeledURI" :"https:\/\/paas-local.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Local","active" :"true"},{"uid" :"odigo_paas_dev","commonName" :"Odigo PaaS Dev","labeledURI" :"https:\/\/paas-dev.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Dev","active" :"true"},{"uid" :"odigo_paas_staging","commonName" :"Odigo PaaS Staging","labeledURI" :"https:\/\/paas-staging.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Staging","active" :"true"},{"uid" :"suite","commonName" :"Odigo Suite","labeledURI" :"http:\/\/suite-it.prosodie.com\/suite","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Suite","label" :"Odigo Suite","active" :"true"},{"uid" :"testvno","commonName" :"Analytics DEV","labeledURI" :"https:\/\/odigo-analytics-dev.prosodie.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Analytics DEV","active" :"true"},{"uid" :"odigoACD_localhost_esg","commonName" :"Odigo ACD ESG","labeledURI" :"http:\/\/localhost:8080\/esg\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ESG","active" :"true"},{"uid" :"odigoACD_localhost_esa","commonName" :"Odigo ACD ESA","labeledURI" :"http:\/\/localhost:8080\/esa\/ui\/service\/loginForm","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo ACD ESA","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dva","commonName" :"Odigo ACD dva (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dva\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dva (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dvb","commonName" :"Odigo ACD dvb (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dvb\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dvb (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dvc","commonName" :"Odigo ACD dvc (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dvc\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dvc (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dvd","commonName" :"Odigo ACD dvd (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dvd\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dvd (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dve","commonName" :"Odigo ACD dve (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dve\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dve (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dvf","commonName" :"Odigo ACD dvf (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dvf\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dvf (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dvg","commonName" :"Odigo ACD dvg (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/dvg\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD dvg (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esw","commonName" :"Odigo ACD esw (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esw\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esw (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esv","commonName" :"Odigo ACD esv (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esv\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esv (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esx","commonName" :"Odigo ACD esx (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esx\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esx (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esy","commonName" :"Odigo ACD esy (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esy\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esy (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esz","commonName" :"Odigo ACD esz (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esz\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esz (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esu","commonName" :"Odigo ACD esu (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esu\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD esu (bodiweb01pdx)","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_dev_dpn","commonName" :"Odigo ACD DEV_DPN (bodiweb01pdx)","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/DEV_DPN\/ui\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"Odigo ACD DEV_DPN (bodiweb01pdx)","active" :"true"},{"uid" :"sushant1","commonName" :"sushant1","labeledURI" :"http:\/\/test.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"sushant1","active" :"true"},{"uid" :"anltics22","commonName" :"asdsd","labeledURI" :"https:\/\/portal-it.prosodie.com\/portal","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"asdsd","active" :"true"},{"uid" :"analytics22","commonName" :"analytics22","labeledURI" :"http:\/\/analytics22.com\/","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"analytics22","active" :"true"},{"uid" :"odigoacd_bodiweb01pdx_esr","commonName" :"Odigo ACD esr","labeledURI" :"https:\/\/bodiweb01pdx.prosodie\/esr\/ui\/","odigoIndicators" :null,"openNewWindow" :"true","productType" :"Routing","label" :"Odigo ACD esr","active" :"true"},{"uid" :"testaproduct","commonName" :"PROBLEM-837","labeledURI" :"https:\/\/testaproduct.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"PROBLEM-837","active" :"true"},{"uid" :"problem837","commonName" :"problem837","labeledURI" :"https:\/\/problem837","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"problem837","active" :"true"},{"uid" :"problem8371","commonName" :"problem8371","labeledURI" :"https:\/\/problem8371","odigoIndicators" :null,"openNewWindow" :"false","productType" :"BCR","label" :"problem8371","active" :"true"},{"uid" :"problem8372","commonName" :"problem8372","labeledURI" :"https:\/\/problem8372","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"problem8372","active" :"true"},{"uid" :"testproductdeletealluser","commonName" :"testProductDeleteAllUser","labeledURI" :"https:\/\/testProductDeleteAllUser.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"testProductDeleteAllUser","active" :"true"},{"uid" :"test13","commonName" :"test13","labeledURI" :"https:\/\/test13.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"test13","active" :"true"},{"uid" :"odigo_paas_auth_local","commonName" :"Odigo PaaS Auth Local","labeledURI" :"https:\/\/paas-auth-local.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Auth Local","active" :"true"},{"uid" :"odigo_paas_auth_dev","commonName" :"Odigo PaaS Auth Dev","labeledURI" :"https:\/\/paas-auth-dev.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Auth Dev","active" :"true"},{"uid" :"odigo_paas_auth_staging","commonName" :"Odigo PaaS Auth Staging","labeledURI" :"https:\/\/paas-auth-staging.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Auth Staging","active" :"true"},{"uid" :"testa","commonName" :"testA","labeledURI" :"https:\/\/testA.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"testA","active" :"true"},{"uid" :"ivrtest","commonName" :"ivrTest","labeledURI" :"https:\/\/ivrtest.prosodie.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"ivrTest","active" :"true"},{"uid" :"routingtest","commonName" :"routingTest","labeledURI" :"http:\/\/bodiweb01pdx.prosodie\/esz\/ui","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Routing","label" :"routingTest","active" :"true"},{"uid" :"ivrdesignerstaging","commonName" :"IVRDesignerST","labeledURI" :"https:\/\/ivr-designer-st.prosodie.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"IVRDesignerST","active" :"true"},{"uid" :"routingstaging","commonName" :"routingstaging","labeledURI" :"https:\/\/routing-st.prosodie.com\/staging_v41\/ui\/service\/acdSearch","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Routing","label" :"routingstaging","active" :"true"},{"uid" :"productwithouttype","commonName" :"productwithouttype","labeledURI" :"https:\/\/productWithouttype.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"productwithouttype","active" :"true"},{"uid" :"product_analytics","commonName" :"productwithouttype","labeledURI" :"https:\/\/product_analytics.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"Analytics","label" :"productwithouttype","active" :"true"},{"uid" :"product_bcr","commonName" :"product_bcr","labeledURI" :"https:\/\/product_bcr.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"BCR","label" :"product_bcr","active" :"true"},{"uid" :"product_ivrdesigner","commonName" :"Product_IVRDesigner-CI","labeledURI" :"https:\/\/ivr-designer-ci.prosodie.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"IVRDesigner","label" :"Product_IVRDesigner-CI","active" :"true"},{"uid" :"product_oam","commonName" :"product_oam","labeledURI" :"https:\/\/product_oa&m.com","odigoIndicators" :null,"openNewWindow" :"true","productType" :"OA&M","label" :"product_oam","active" :"true"},{"uid" :"a11","commonName" :"a1","labeledURI" :"https:\/\/analyticsTest12a1.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Analytics","label" :"a1","active" :"true"},{"uid" :"pcmtest","commonName" :"pcmTest","labeledURI" :"https:\/\/pcmtTest.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"PCM","label" :"pcmTest","active" :"true"},{"uid" :"testp","commonName" :"testpc","labeledURI" :"https:\/\/testpe.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"testpc","active" :"true"},{"uid" :"product_ivr_ci","commonName" :"PRODUCT_IVR_CI","labeledURI" :"https:\/\/ivr-designer-ci.prosodie.com\/appNservices.html","odigoIndicators" :null,"openNewWindow" :"false","productType" :"IVRDesigner","label" :"PRODUCT_IVR_CI","active" :"true"},{"uid" :"product_routing_st","commonName" :"PRODUCT_ROUTING_ST","labeledURI" :"https:\/\/routing-st.prosodie.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Routing","label" :"PRODUCT_ROUTING_ST","active" :"true"},{"uid" :"recorder_st","commonName" :"recorder_st","labeledURI" :"https:\/\/record-st.prosodie.com\/odigorecorder ","odigoIndicators" :null,"openNewWindow" :"false","productType" :"Record","label" :"recorder_st","active" :"true"},{"uid" :"new_console","commonName" :"new_console","labeledURI" :"https:\/\/console-it.prosodie.com\/console","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"new_console","active" :"true"},{"uid" :"testproductcreate2","commonName" :"testproductcreate","labeledURI" :"https:\/\/testproductcreate2.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"testproductcreate","active" :"true"},{"uid" :"testproductcreate3","commonName" :"testproductcreate","labeledURI" :"https:\/\/testproductcreate3.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"testproductcreate","active" :"true"},{"uid" :"testproductcreate4","commonName" :"testproductcreate4","labeledURI" :"https:\/\/testproductcreate4.com","odigoIndicators" :null,"openNewWindow" :"false","productType" :"null","label" :"testproductcreate4","active" :"true"},{"uid" :"odigo_paas_it","commonName" :"Odigo PaaS IT","labeledURI" :"http:\/\/10.24.30.46:8280","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS IT","active" :"true"},{"uid" :"odigo_paas_auth_it","commonName" :"Odigo PaaS Auth IT","labeledURI" :"http:\/\/10.24.30.46:8280","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"Odigo PaaS Auth IT","active" :"true"},{"uid" :"mevo2dev","commonName" :"MeVo2","labeledURI" :"http:\/\/voicemail-test.prosodie.com:8080","odigoIndicators" :null,"openNewWindow" :"true","productType" :"null","label" :"MeVo2","active" :"true"}],
    "languageFlag":{"langid":"en"},
    "favoris" : [],
    
    "languages":[ {"lang" : "fr","label" : "Fran&ccedil;ais","selected" : false}, {"lang" : "en","label" : "English","selected" : true}, {"lang" : "de","label" : "Deutsch","selected" : false}, {"lang" : "es","label" : "Espa&ntilde;ol","selected" : false}, {"lang" : "nl","label" : "Dutch","selected" : false}, {"lang" : "it","label" : "Italian ","selected" : false}, {"lang" : "pt","label" : "Portuguese ","selected" : false}],
    "context" : {"path" : "https://portal-it.prosodie.com/portal/"},
    "hideproductId":{"hideproductKeyId":"portal"},

    /* ===========================================================
     * Initialization function, in charge of displaying the Header
     * =========================================================== */
    "init" : function(data) {
                if (data.div) {this.div = data.div;}
                var _header = $("#" + this.div).html("");

                if (typeof data.notificationDuration != "undefined") {                
                    this.notificationDuration = data.notificationDuration;
                }

                
                var top_NavigationBar = "<div class=\"navbar navbar-default navbar-fixed-top\" role=\"navigation\">";
                top_NavigationBar += "<div class=\"container\"><div class=\"row\"><div class=\"col-md-2\"> <div class=\"navbar-header\">";
                top_NavigationBar += "<button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">";
                top_NavigationBar += "<span class=\"sr-only\">Toggle</span> <span class=\"icon-bar\"></span><span class=\"icon-bar\">";
                top_NavigationBar += "</span><span class=\"icon-bar\"></span></button>";

                
                var logo_Component="";
                if (this.customers.organizationName!= null && this.customers.labeledURI!=null) {
                    logo_Component  =   "<a class=\"navbar-brand\" id=\"navbar-brand\" href=\"#\" onclick=" + this.varName + "._OnImageClick('"+ this.logo.odigo_url + "');>";
                    logo_Component +=   "<img src=\""+this.customers.labeledURI+"\" id=\"logoimg\" alt=\""+this.customers.organizationName+"\" title=\""+this.customers.organizationName+"\" height=\"52\"/>";
                    logo_Component +=   "</a></div></div>";
                } else {
                    logo_Component  =   "<a class=\"navbar-brand\" id=\"navbar-brand\" href=\"#\" onclick=" + this.varName + "._OnImageClick('"+ this.logo.odigo_url + "');>";
                    logo_Component +=   "<img src=\""+this.context.path+"odigo/img/odigo.png\"  id=\"logoimg\" alt=\"Odigo\" title=\"Odigo\" />";
                    logo_Component +=   "</a></div></div>";
                }

                
                var product_Component  = "<div class=\"col-md-10\" id=\"nav-links\"><div class=\"navbar-collapse collapse\"><div class=\"row\"><div id=\"nav-marques\">";
                product_Component += "<a href=\"#\" class=\"arrow prev\" id=\"prev\"></a>";
                product_Component += "<div id=\"marques\"><ul class=\"cycle-slideshow\" data-cycle-slides=\"li\" data-cycle-fx=carousel data-cycle-timeout=0 data-cycle-next=\"#next\" data-cycle-prev=\"#prev\" data-allow-wrap=\"false\">";
                product_Component += "<li "+(data.product==this.selectedProduct ? "class=\"active\"" : "")+"><a href=\"#\" onclick=" + this.varName + "._OnImageClick('"+ this.logo.odigo_url + "'); id=\"home\" class=\"home\">Home</a></li>";
                var _selected = false;
                for (tmp in this.products) {
                    if (this.products[tmp].uid!=this.hideproductId.hideproductKeyId) {
                        if(this.products[tmp].uid == data.product){
                            _selected = true;
                        } else {
                            _selected = false;
                        }
                        product_Component += "<li  id=\"" + this.products[tmp].uid + "\" name=\"products_menu\"" +(_selected ? "class=\"active\"" : "")+ " >";
                        product_Component += "<a href=\"#\" title = "+ this.products[tmp].uid +" onclick="+ this.varName + "._OnProductChange('" + this.products[tmp].labeledURI + "','" + this.products[tmp].uid + "','" + this.products[tmp].openNewWindow + "','en');>" + this.products[tmp].commonName + "</a></li>";
                    }
                }
                product_Component += "</ul></div><a href=\"#\" class=\"arrow next\" id=\"next\"></a></div>";
                

                
                

                
                var contact_Component = "<ul class=\"nav navbar-nav navbar-right\" id=\"nav-right\"><li><a href=\"#\" onclick=" + this.varName + "._OnContactClick(); "+ "class=\"contact\" data-toggle=\"modal\" data-target=\"#popin_contact\">Contact</a></li>";

                
                 var contact_Popin = "";
                 contact_Popin  = "<div class=\"modal fade\" id=\"popin_contact\" tabindex=\"-1\"><div class=\"modal-dialog\"><div class=\"modal-content\"><form class=\"form-horizontal\" role=\"form\"><div class=\"modal-header\">";
                 contact_Popin += "<button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">&times;</button><h4 class=\"modal-title\"><strong>Contact</strong></h4></div><div class=\"modal-body\">";
                 contact_Popin += "<div class=\"modal-body form-block\"><h5><strong>Prosodie hotline contacts</strong></h5><div class=\"\"><div class=\"form-horizontal\">If you have any problems, you can reach the Prosodie hotline 7/7 and 24/24 at:</div>";
                 contact_Popin += "<div class=\"text-center\"><a href=\"tel:+33 811 01 12 34\">+33 811 01 12 34</a><br><a href=\"mailto:hotline-client@prosodie.com\">hotline-client@prosodie.com</a>";
                 contact_Popin += "<br></div></div></div></div><div class=\"modal-footer\">" + this._getVersion(data.version) + "</div></form></div></div></div>";
                 this.Popin = contact_Popin;
                
                
                var language_Component="";
                for (tmp in this.languages) {
                    if (this.languages[tmp].lang === this.languageFlag.langid) {
                        language_Component  = "<li class=\"langs\"><a href=\"#\" type=\"button\" class=\"dropdown-toggle " + this.languages[tmp].lang+ "\" data-toggle=\"dropdown\">";
                        language_Component += "<span class=\"flag\"></span>" + this.languages[tmp].label+ "<span class=\"caret\"></span></a><ul class=\"dropdown-menu\" role=\"menu\">";
                    }
                }
                for (tmp in this.languages) {
                    if (this.languages[tmp].lang === this.languageFlag.langid) {
                        continue;
                    }
                    language_Component  += "<li><a href=\"#\" onclick=" + this.varName + "._OnLanguageChange('" + this.languages[tmp].lang + "'); class=\""+ this.languages[tmp].lang + "\" data-lang=\"" + this.languages[tmp].lang + "\"> <span class=\"flag\"></span>"+ this.languages[tmp].label + "</a></li>";
                }
                language_Component  += "</ul></li></ul></div></div></div></div><span id=\"arrow_header\"></span></div></div></div></div>";
				
                 
                 var loaderBar="<div id='loader' class='loader left'>" + "</div>";   

                
                
                
                var userLable  = "<div class=\"col-md-4 col-xs-12\" style='white-space: nowrap;'><ul class=\"user\"> <li><p style='white-space: nowrap;'><span class=\"glyphicon glyphicon-user\"></span>" + this.user.userName + "</p></li>";
                userLable += "<li class=\"logout\"><a href=\"#\" onclick=" + this.varName + "._OnLogout(); "+ " data-toggle=\"modal\" data-target=\"\">Disconnection</a>";
                userLable += "<span class=\"glyphicon glyphicon-remove\"></span></li></ul></div>";
				
				var menuUserBar  = "<div id=\"topbar\" class=\"clearfix navbar-fixed-top\"><div class=\"container\"><div class=\"row\">";
				var topicMenu 	= "<div class=\"col-md-6 col-md-offset-2 col-xs-12\"><div class=\"rubriques \">";
				var topicLabel = "";
				var lastItem = 1;
                for (tmp in data.topics) {
					if(lastItem > 4){
						break;
					}
                    if (data.topics.hasOwnProperty(tmp)) {
                    	topicMenu += "<div class=\"rub\">";
						if(data.topics[tmp].show){
							topicMenu += "<button type=\"button\" class=\"dropdown-toggle\" data-toggle=\"dropdown\">";
							topicLabel = data.topics[tmp].label; 
							if(topicLabel.indexOf("data:image") == 0){
								topicMenu += "<img src="+topicLabel+" />";
							} else {
								topicMenu += data.topics[tmp].label; 
							}
							topicMenu += "<span class=\"caret\"></span></button>";
						}
						var subMenuExist = false;
						for(sm1 in data.topics[tmp].next){
							if(data.topics[tmp].next[sm1].next){
								if(data.topics[tmp].next[sm1].next instanceof Array){
									subMenuExist = true;
									break;
								}
							}
						}
						if(lastItem == 4 && !subMenuExist){
							topicMenu += "<div class=\"dropdown-menu last\" role=\"menu\">";
						} else {
							topicMenu += "<div class=\"dropdown-menu\" role=\"menu\">";
						}
                		
                		topicMenu += "<div class=\"row\">";
                    	
						if (data.topics[tmp].show) {
							var divClosed = true;
							lastItem = lastItem  + 1;
                            if (data.topics[tmp].next) {
                                for (tmp1 in data.topics[tmp].next) {
									if(data.topics[tmp].next[tmp1].show){   
										if (data.topics[tmp].next.hasOwnProperty(tmp1)) {
											if(data.topics[tmp].next[tmp1].next instanceof Array){	
												if(!divClosed){
													topicMenu += "</div>";
												}												
												topicMenu += "<div class=\"col-sm-3\">";
												divClosed = false;
												topicMenu += "<h4>" + data.topics[tmp].next[tmp1].label + "</h4>"; 
												for (tmp2 in data.topics[tmp].next[tmp1].next){
													if(data.topics[tmp].next[tmp1].next[tmp2].show){ 
														if(data.topics[tmp].next[tmp1].next[tmp2].newColumn)
														{
															if(!divClosed){
																topicMenu += "</div>";
															}												
															topicMenu += "<div class=\"col-sm-3\">";
															divClosed = false;
															topicMenu += "<h4 style='background:none'>&nbsp;</h4>"; 
														}
														if(data.topics[tmp].next[tmp1].next[tmp2].next instanceof Array){
															topicMenu += "<h5>";
															topicMenu += data.topics[tmp].next[tmp1].next[tmp2].label; 
															topicMenu += "</h5>";
															topicMenu += "<ul>";	
															for (tmp3 in data.topics[tmp].next[tmp1].next[tmp2].next){
																if(data.topics[tmp].next[tmp1].next[tmp2].next[tmp3].show){
																	topicPath = data.topics[tmp].next[tmp1].next[tmp2].next[tmp3].next;
																	if(data.checkPortalContext == 0){
																		topicPath = this.context.path + topicPath;
																	}
																	topicMenu += "<li><a href=\""+ topicPath  +"\" id=\""+data.topics[tmp].next[tmp1].next[tmp2].next[tmp3].id+"\" onclick=\"" + this.varName + "._OnTopicChange('"+data.checkPortalContext+"','" + data.topics[tmp].next[tmp1].next[tmp2].next[tmp3].next+ "', event);\">" + data.topics[tmp].next[tmp1].next[tmp2].next[tmp3].label + "</a></li>";
																} 
															}	
															topicMenu += "</ul>";
														} else {	
															if(tmp2 == 0){															
																topicMenu += "<ul>";
															}	
															topicPath = data.topics[tmp].next[tmp1].next[tmp2].next;
															if(data.checkPortalContext == 0){
																topicPath = this.context.path + topicPath;
															}													
															topicMenu += "<li><a href=\""+ topicPath +"\" id=\""+data.topics[tmp].next[tmp1].next[tmp2].id+"\" onclick=\"" + this.varName + "._OnTopicChange('"+data.checkPortalContext+"','" + data.topics[tmp].next[tmp1].next[tmp2].next + "', event);\">" + data.topics[tmp].next[tmp1].next[tmp2].label + "</a></li>";	
															if(tmp2 == (data.topics[tmp].next[tmp1].next.length -1)){
																topicMenu += "</ul>";																
															}														
														}
													}
												}												
												topicMenu += "</div>"; 
												divClosed = true;
											} else {
												if(lastItem > 4 && tmp1 == 0){
													topicMenu += "<div class=\"col-md-12\">";
												} else if(tmp1 == 0 || subMenuExist){
													if(!divClosed){
														topicMenu += "</div>";
													}												
													topicMenu += "<div class=\"col-sm-3\">";
													divClosed = false;
													if(tmp1 == 0){
														topicMenu += "<ul>";
													}
												}												
												
												topicPath = data.topics[tmp].next[tmp1].next;
												if(data.checkPortalContext == 0){
													topicPath = this.context.path + topicPath;
												}								
												if(subMenuExist) {
													topicMenu += "<h4 class=\"h4menulink\"><a href=\"topicPath\" id=\""+data.topics[tmp].next[tmp1].id+"\" onclick=\"" + this.varName + "._OnTopicChange('"+data.checkPortalContext+"','" + data.topics[tmp].next[tmp1].next + "',event);\">" + data.topics[tmp].next[tmp1].label + "</a></h4>";												
												}
												else {
													topicMenu += "<li><a href=\""+ topicPath +"\" id=\""+data.topics[tmp].next[tmp1].id+"\" onclick=\"" + this.varName + "._OnTopicChange('"+data.checkPortalContext+"','" + data.topics[tmp].next[tmp1].next + "',event);\">" + data.topics[tmp].next[tmp1].label + "</a></li>";												
												}
												if(tmp1 == (data.topics[tmp].next.length -1) || subMenuExist){
													if(tmp1 == (data.topics[tmp].next.length -1)){													
														topicMenu += "</ul>";
													}
													topicMenu += "</div>"; 
													divClosed = true;
												}	
											}				
										}
									} else {
										if(!(data.topics[tmp].next[tmp1].next instanceof Array)){
											if(tmp1 == 0){
												if(!divClosed){
														topicMenu += "</div>";
												}												
												topicMenu += "<div class=\"col-sm-3\">";
												divClosed = false;
												topicMenu += "<ul>";
											}
										
											if(tmp1 == (data.topics[tmp].next.length -1)){
												topicMenu += "</ul>";
												topicMenu += "</div>"; 	
												divClosed = true;												
											}
										}										
									}
                                }
                            }                             
                        }                    
                     	topicMenu += "</div></div></div>";    
                    }
                }
                topicMenu += "</div></div>";
				 
				menuUserBar += topicMenu+userLable+"</div></div></div>";

                
                
                var infoMessage = "";

                 
                var notificationBar="<div id='alert-fixed' class='alert' style='display: none;'>" + "</div>";
                
                 
                 
                 var headerWidget = top_NavigationBar + logo_Component + product_Component + contact_Component + language_Component + menuUserBar + notificationBar;

                
                this.totalheaderwidget = headerWidget;
                
                
                _header.html(_header.html() +this.totalheaderwidget);
                
                    
                var popinContact=this.Popin+"<span id=\"popinContactOfPortal\"></span>";
                _header.html(_header.html() +popinContact);
                  
                
                
                if(typeof $(".cycle-slideshow").cycle != "undefined"){
                	$('.cycle-slideshow').cycle();
                }
                
                
                if (data.uid && data.uid != this.user.uid) {
                    this._checkUserInconsistency(data.uid);
                }
                
                
				
                var navWidth = $('#nav-links').width() - $('#nav-right').width() - 25;
				$('#nav-marques').css({'width' : navWidth });

				$(window).resize(function(){
					var navWidth = $('#nav-links').width() - $('#nav-right').width() - 25;
					$('#nav-marques').css({'width' : navWidth });
				});
     },



           
    "init2" : function(data) {
             this.init(data);   
     },


    /* ===========================================================
     * Public functions
     * =========================================================== */
    
    "showNotification":  function(data) {
                // if (Header.debug) {
                //    console.log(" [HeaderWidget] showNotification : " + data);
                // }
                Header._ShowNotification(data);  
            },

     
     "showLoader":  function(data) {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] showLoader : " + data);
                // }
                Header._ShowLoader(data);  
          },

     
     "hideLoader":  function(data) {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] hideLoader : " + data);
                // }
                Header._HideLoader(data);  
          },

     
     "OnBookmarkAdd":  function() {
                var data = {"url": this.context.path + "odigo/web/webservices/bookmarks/add", "timeout":3000};
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] OnBookmarkAdd : " + url);
                // }
                return data;
          },

     
     "OnProductChange":  function(labeledURI, productUid, openNewWindow, currentLanguage) {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] OnProductChange");
                // }
                ; // Nothing to do by default
          },

     
     "OnTopicChange": function(checkContext, topicChange) {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] OnTopicChange");
                // }
                // by default, return false to indicate that redirection has not been made
                return false;
     },

     
     "OnLanguageChange":  function(ws_url,languageFlag) {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] OnLanguageChange");
                // }
                ; // Nothing to do by default
          },
          
    
    "checkUserInconsistency":  function(uid) {
                var errorMessage = "The logged user '{0}' differs from the user '{1}' fetched from this module. Please remove all your browser cookies and refresh the current page !";
                errorMessage = errorMessage.replace("{0}",this.user.uid);
                errorMessage = errorMessage.replace("{1}",uid);
                 Header._ShowNotification({"level":"error",
                                         "clazz":"alert-danger",
                                         "glyphiconclass":"glyphicon-remove-sign",
                                         "message":errorMessage,
                                         "close":"x", 
                                         "duration":5000});
                console.log("[HeaderWidget] The user '" + this.user.uid + "' in the Header Widget differs from the product uid '" + uid + "'. You should remove all your cookies !");
          },
          
                    
      
    "OnLogout":  function() {
                // if (Header.debug) {
                //     console.log(" [HeaderWidget] OnLogout");
                // }
                ; // Nothing to do by default
          },
          
    /* ===========================================================
     * Private functions
     * =========================================================== */
    
    "_OnImageClick": function(_imgUrl) {
                Header.showLoader('');
                $(location).attr('href', this.context.path+_imgUrl);
                window.name = this.selectedProduct;
            },

    
    "_OnBookmarkAdd": function() {
                Header.showLoader('');
                var newBookMark={"id": "bkm_" + (new Date()).getTime(),
                                 "label":document.title,
                                 "url":window.location.href,
                                 "icon": this.context.path+"odigo/img/favori1.jpg"
                                 };

                var ws_url = "";
                var ws_timeout = 3000;
                try {
                    var data = this.OnBookmarkAdd();
                    ws_url = data.url;
                    ws_timeout = data.timeout;
                    if (ws_url == undefined) {
                        ws_url = "";
                        throw {"message":"Unable to retreive Webservice URL !"};
                    }
                    if (ws_timeout == undefined) {
                        ws_timeout = 3000;
                    }
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] Custom OnBookmarkAdd function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] Custom OnBookmarkAdd function raised an error : " + err.message);
                    }
                }

                if (ws_timeout<1000) {
                    this._ShowNotification({"level":"error",
                                         "clazz":"alert-danger",
                                         "glyphiconclass":"glyphicon-remove-sign",
                                         "message":"Unable to add the bookmark. Please contact your administrator.", 
                                         "close":"x",
                                         "duration":5000});
                    console.log("[HeaderWidget] OnBookmarkAdd function returned the WebService timeout '" + ws_timeout + "' which is invalid !");
                    Header.hideLoader('');
                    return;
                }

                var regexp_url = /^(https?:\/\/)?([\da-z\.-]+)([a-z\.]{2,6})([\/\w \.-@#~%\?$]*)*\/?$/;
                if (! regexp_url.test(ws_url)) {
                    this._ShowNotification({"level":"error",
                                         "clazz":"alert-danger",
                                         "glyphiconclass":"glyphicon-remove-sign",
                                         "message":"Unable to add the bookmark. Please contact your administrator.", 
                                         "close":"x",
                                         "duration":5000});
                    console.log("[HeaderWidget] OnBookmarkAdd function returned the WebService URL '" + ws_url + "' which is invalid !");
                    Header.hideLoader('');
                    return;
                }
                
                $.support.cors = true;  
                $.ajax({
                    //crossDomain: true,
                     contentType : 'application/json; charset=utf-8',
                    //contentType : 'application/x-www-form-urlencoded; charset=utf-8',
                    xhrFields: {
                        withCredentials: true
                    },
                    dataType : 'json',
                    type:'POST',
                    // url:this.context.path+"odigo/web/webservices/bookmarks/add/"+this.user.uid+"/",
                    url: ws_url,
                    timeout: ws_timeout,
                    data:JSON.stringify(newBookMark),
                    success: function(data){
                        Header.hideLoader('');
                        if(data.status === "FAILURE"){
				                            	if(data.code === 100000){
							    					window.location.href = this.context.path+"/odigo/web/redirectToErrorPage";
							    				}else{
							    					Header.showNotification({"message":data.message, "level": "error"});
							    				}
				                            }else{
					                     				                        	
					                        	Header.hideLoader('');
					                        	Header.showNotification({"message":data.message, "level": "success", "duration": Header.notificationDuration});
					                        	setTimeout( "window.location.reload();", 1000);
				                        	}
                        
                    },
                    error: function(data){
                        Header.hideLoader('');
                        Header._ShowNotification({"level":"error",
                                                "clazz":"alert-danger",
                                                "glyphiconclass":"glyphicon-remove-sign",
                                                "message":"Unable to add the bookmark. Please contact your administrator.", 
                                                "close":"x",
                                                "duration":5000});
                        console.log("[HeaderWidget] addBookmark Webservice request failed and returned '" + data + "' !");
                    }
                });
            },

    
    "_OnProductChange": function(_labeledURI, _productUid, _openNewWindow, _currentLanguage) {
                try {
                    this.OnProductChange(_labeledURI, _productUid, _openNewWindow, _currentLanguage);
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] Custom OnProductChange function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] Custom OnProductChange function raised an error : " + err.message);
                    }
                }
                var url = _labeledURI;
                if(url.indexOf('?') == -1){
                    url = url + '?';            // Append a '?' to url.
                }else{
                    url = url + '&';           // Append a '&' to url.
                }                                
                url = url + "productUID="+_productUid +"&lang=" + _currentLanguage.toUpperCase();
                url = encodeURI(url);
                if (_openNewWindow === "false") {
                    Header.showLoader('');
                    $(location).attr('href', url);
                    window.name = _productUid;
                } else {
                    window.open(url, _productUid);
                }
            },

    
    "_OnContactClick": function() {
                Header.showLoader('');
                $('#popinContactOfPortal').html('');
                Header.hideLoader('');
            },

     
     "_OnTopicChange": function(_checkContext, _topicChange, e) {
     			e.preventDefault();
     			var isRedirected = false;
                try {
                    isRedirected = this.OnTopicChange(_checkContext, _topicChange);
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] Custom OnTopicChange function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] Custom OnTopicChange function raised an error : " + err.message);
                    }
                }
    
    			if(!isRedirected){ 			  			
	                if (_checkContext==="0") {
	                    Header.showLoader('');
	                    var topicPath=this.context.path+ _topicChange;
	                    $(location).attr('href', topicPath);
	                } else {
	                    Header.showLoader('');
	                    $(location).attr('href', _topicChange);
	                }
    			}
            },

    
    "_OnBookMarkClick": function(_bookMarKUrl) {
                Header.showLoader('');
                $(location).attr('href', _bookMarKUrl);
            },

    
    "_OnLanguageChange": function(_languageFlag) {
                //default url is relative to the current root so it stays in the same domain
                var ws_url = "odigo/web/users/updateUserLang/" + this.user.uid + "/language" +"?language="+_languageFlag;
                var ws_timeout = 3000;
                try {
                    var data = this.OnLanguageChange("portal/"+ws_url, _languageFlag);
                    if (data && data.url){
                        ws_url = data.url;
                    }else{
                        ws_url = this.context.path + ws_url;
                    }
                    
                    if (data && data.timeout) {
                        ws_timeout = data.timeout;
                    }
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] Custom OnLanguageChange function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] Custom OnLanguageChange function raised an error : " + err.message);
                    }
                }
				
				$.support.cors = true;  
                $.ajax({
                    type: "POST",                    
                    //crossDomain: true,
                    //contentType : 'application/json; charset=utf-8',
                    contentType : 'application/x-www-form-urlencoded; charset=utf-8',
					
                    xhrFields: {
                        withCredentials: true
                    },
					
                    dataType : 'json',
                    url: ws_url,
                    timeout: ws_timeout,
                    success: function(data) {
                        Header.hideLoader('');
                        if((window.location.href).indexOf("lang") > 0) {
                           window.location.href = window.location.href.substring(0,(window.location.href).indexOf("lang"))+"lang="+_languageFlag.toUpperCase();
                        }
                        else {
                        window.location.reload();
                        }
                        
                    },
                    error: function(data){
                        Header.hideLoader('');
                        Header._ShowNotification({"level":"error",
                                                "clazz":"alert-danger",
                                                "glyphiconclass":"glyphicon-remove-sign",
                                                "message":"Unable to update user's selected language.", 
                                                "close":"x",
                                                "duration":5000});
                        console.log("[HeaderWidget] languageChange Webservice request failed and returned '" + data + "' !");
                    }
                });
            },

    
    "_ShowNotification": function(_notificationInfo) {
                var classe="";
                var glyphiconclass="";
                var message="";
                var close="";
                var duration="";

                
                $('#alert-fixed').slideUp();
                $('#alert-fixed').removeClass("alert-info");
                $('#alert-fixed').removeClass("alert-warning");
                $('#alert-fixed').removeClass("alert-success");
                $('#alert-fixed').removeClass("alert-danger");

                
                var notificationInfo = { "level":"info",
                                         "clazz":"alert-info",
                                         "glyphiconclass":"glyphicon-info-sign",
                                         "message":"Information", 
                                         "close":"x",
                                         "duration":0};

                if (typeof _notificationInfo == "undefined") { 
                    
                    classe=notificationInfo.clazz;
                    glyphiconclass=notificationInfo.glyphiconclass;
                    message=notificationInfo.message;
                    close=notificationInfo.close;
                    duration=notificationInfo.duration;
                } else {
                    if (typeof _notificationInfo.level != "undefined") {
                        
                        switch (_notificationInfo.level) {
                            case "info": 
                                classe="alert-info";
                                break;
                            case "warn":
                                classe="alert-warning";
                                break;
                            case "success":
                                classe="alert-success";
                                break;
                            case "error":
                                classe="alert-danger";
                                break;
                            default: 
                                classe="alert-info";
                                break;
                        }
                    } else {
                        
                        classe=notificationInfo.clazz;
                    }

                    if (typeof _notificationInfo.glyphiconclass == "undefined") { 
                        
                        switch (classe) {
                            case "alert-info":
                                glyphiconclass = "glyphicon-info-sign";
                                break;
                            case "alert-warning":
                                glyphiconclass = "glyphicon-warning-sign";
                                break;
                            case "alert-success":
                                glyphiconclass = "glyphicon-ok-sign";
                                break;
                            case "alert-danger":
                                glyphiconclass = "glyphicon-remove-sign";
                                break;
                        }
                    } else {
                        glyphiconclass=_notificationInfo.glyphiconclass;
                    }

                    if (typeof _notificationInfo.message == "undefined") {
                        message = notificationInfo.message;
                    } else {
                        message = _notificationInfo.message;
                    }

                    if (typeof _notificationInfo.close == "undefined") {
                        close = notificationInfo.close;
                    } else {
                        close = _notificationInfo.close;
                    }

                    if (typeof _notificationInfo.duration == "undefined") {
                        duration = notificationInfo.duration;
                    } else { 
                        if (typeof _notificationInfo.duration == "number" && _notificationInfo.duration>0) {
                            duration = _notificationInfo.duration;
                        } else {
                            duration = notificationInfo.duration;
                        }
                    }
                }

                var notificationData = "<div class='container'>" +
                                       "<span id='glyph' class='glyphicon " + glyphiconclass + "'></span>" +
                                       "<strong>"+message+"</strong>"+
                                       "<button class='close' type='button'>"+close+"</button>"+
                                       "</div>";

                $('#alert-fixed').addClass(classe);
                $('#alert-fixed').html(notificationData);
                $('#alert-fixed').slideToggle();
                $('#main-container').css({'margin-top' : '50px' });

                $('#alert-fixed .close').on('click', function(e) {
                        e.preventDefault();
                        $('#alert-fixed').slideToggle();
                        $('#main-container').css({'margin-top' : '0' });
                        });

                if (duration!=0) {
                    setTimeout( "if($('#alert-fixed').find(':hover').length === 0) { $('#alert-fixed').slideUp(); }", duration);
                }
            },
            
    
    "_ShowLoader": function(_loaderInfo) {
               var message="";
               if (typeof _loaderInfo != "undefined")  {
                   if (typeof _loaderInfo.message != "undefined") {
                       message=_loaderInfo.message;
                   }
                }

                var loaderData = "<img class='spinner' src=\""+this.context.path+"odigo/img/loading.gif\" />" + "<span class='spinnerText' >"+message+"</span>";

                $('#loader').html(loaderData);
            },

    
    "_HideLoader": function(_loaderInfo) {
                $('#loader').html('');
            },

    
    "_getVersion": function(_version) {
                var version = this.hideproductId.hideproductKeyId + " version: 1.7.0-SNAPSHOT-20170717.103910";
                try {
                    if (_version.length!=0) {
                        version = $('<div/>').text(_version).html().replace("\n","<br/>") + "<br/>" + version;
                    }
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] _getVersion function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] _getVersion function raised an error : " + err.message);
                    }
                }

                return version;
            },
            
      
    "_checkUserInconsistency": function(_uid) {
                try {
                    this.checkUserInconsistency(_uid);
                }
                catch(err) {
                    if (typeof err == 'string' || err instanceof String) {
                        console.log("[HeaderWidget] Custom checkUserInconsistency function raised an error : " + err);
                    } else {
                        console.log("[HeaderWidget] Custom checkUserInconsistency function raised an error : " + err.message);
                    }
                }
            },
            
             
    "_OnLogout": function() {
		        try{
		            var data = this.OnLogout();
		        }
		        catch(err) {
			          if (typeof err == 'string' || err instanceof String) {
			              console.log("[HeaderWidget] Custom OnLogout function raised an error : " + err);
			          } else {
			              console.log("[HeaderWidget] Custom OnLogout function raised an error : " + err.message);
			          }
			    }
				window.location.href=this.context.path+"/logout";
		     },

    /* ========================================
     * Widget private parameters. DO NOT MODIFY
     * ======================================== */
    "debug"                : true,        // Display debug information on the console
    "varName"              : "Header",    // Name of the variable containing the widget
    "div"                  : "header",    // Default div to write the widget into
    "Popin"                : "contactpopin",
    "selectedProduct"      : "portal",    //Default selected product id for odigo application
    "totalheaderwidget"    : "headerwidget",
    "notificationDuration" : 5000
};