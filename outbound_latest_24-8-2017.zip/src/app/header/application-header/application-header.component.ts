import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'od-app-header',
  templateUrl: './application-header.component.html',
  styleUrls: ['./application-header.component.scss']
})
export class ApplicationHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
