import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'od-call-reasons',
  templateUrl: './call-reasons.component.html',
  styleUrls: ['./call-reasons.component.scss']
})
export class CallReasonsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
