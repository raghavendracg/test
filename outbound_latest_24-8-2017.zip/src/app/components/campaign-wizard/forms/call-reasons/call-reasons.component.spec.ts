import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallReasonsComponent } from './call-reasons.component';

describe('CallReasonsComponent', () => {
  let component: CallReasonsComponent;
  let fixture: ComponentFixture<CallReasonsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallReasonsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallReasonsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
