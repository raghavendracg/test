export function getBasicData(rows = 10, calendarColumns): any[] {
  const items = [];
  let newCol;
  for (let row = 0; row < rows; row++) {
    newCol = {};
    for (let col = 0; col < calendarColumns.length; col++) {
      if (calendarColumns[col].data === 'id') {
        // newCol[calendarColumns[col].data] = '#' + (row + 1); to enable id working vishal 3 of 3
      } else {
        newCol[calendarColumns[col].data] = row + '-' + col;
      }
    }
    items.push(newCol)
  }
  console.log(items);
  return items;
}
