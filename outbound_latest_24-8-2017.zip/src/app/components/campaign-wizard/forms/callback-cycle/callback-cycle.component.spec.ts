import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CallbackCycleComponent } from './callback-cycle.component';

describe('CallbackCycleComponent', () => {
  let component: CallbackCycleComponent;
  let fixture: ComponentFixture<CallbackCycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CallbackCycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CallbackCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
