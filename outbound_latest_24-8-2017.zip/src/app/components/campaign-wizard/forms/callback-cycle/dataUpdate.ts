export function getBasicDataUpdate(rows = 10, calendarColumns = []): any[] {
  const items = [];
  let  newCol;
    for (let col = 0; col < calendarColumns.length; col++) {
      newCol = {};
      for (let ii = 0; ii < Object.keys(calendarColumns[col]).length; ii++) {
        newCol[Object.keys(calendarColumns[col])[ii]] = calendarColumns[col][Object.keys(calendarColumns[col])[ii]];
    }
    items.push(newCol)
  }
  return items;
}
