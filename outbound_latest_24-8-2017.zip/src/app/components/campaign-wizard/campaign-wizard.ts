import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'od-campaign-wizard',
  templateUrl: './campaign-wizard.component.html',
  styleUrls: ['./campaign-wizard.component.scss']
})
export class CampaignWizardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
