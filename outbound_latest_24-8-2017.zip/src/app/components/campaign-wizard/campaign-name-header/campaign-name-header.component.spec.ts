import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CampaignNameHeaderComponent } from './campaign-name-header.component';

describe('CampaignNameHeaderComponent', () => {
  let component: CampaignNameHeaderComponent;
  let fixture: ComponentFixture<CampaignNameHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CampaignNameHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CampaignNameHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
