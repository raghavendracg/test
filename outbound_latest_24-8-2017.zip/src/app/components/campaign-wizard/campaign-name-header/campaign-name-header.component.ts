import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'od-campaign-name-header',
  templateUrl: './campaign-name-header.component.html',
  styleUrls: ['./campaign-name-header.component.scss']
})
export class CampaignNameHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
