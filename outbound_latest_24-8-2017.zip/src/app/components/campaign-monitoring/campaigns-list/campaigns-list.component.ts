import { Component, OnInit, HostListener, Inject, EventEmitter, Output } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { CampaignsService } from '../../../http-services/campaigns.service';
import { Observable } from 'rxjs/Observable';
import { QuickActionMenuClass } from './quick-action-menu-class'; // fetch quick action data
import { CommandService } from '../../../services/websocket/command.service';
import { MessageService } from '../../../services/websocket/message.service';
@Component({
   selector: 'od-campaigns-list',
   templateUrl: './campaigns-list.component.html',
   styleUrls: ['./campaigns-list.component.scss'],
   providers: [QuickActionMenuClass]
})

export class CampaignsListComponent implements OnInit {
   pageTitle = 'CAMPAIGN';
   snackbarVisible = true;
   snackConfigData = [];
   isCampaignMenuVisible: Array<Boolean> = [];
   campaignsData;
   checkCampaignDataLoaded = false;
   outSearchValue; // to Capture Search Text exposed from Search Filter component
   readyStatus = true;
   quickActionMenuClassData;
   tabTypeSelected;
   constructor(
      private commandService: CommandService,
      private messageService: MessageService,
      private campaignsService: CampaignsService,
      @Inject(DOCUMENT) private document: any,
      private quickActionMenuClass: QuickActionMenuClass) {
      this.quickActionMenuClassData = quickActionMenuClass.quickActionData;
   }

   @HostListener('window:scroll', [])
   onWindowScroll() {
      const number = this.document.body.scrollTop;
      const documentHeight = window.innerHeight;
      const totalHeight = this.document.body.scrollHeight;
      if ((number + documentHeight) === totalHeight) {
         this.snackConfigData = [true, 2000, 'LOADING-START-MESSAGE'];
      }
   }

   ngOnInit() {
      // this.messageService.subscribe('', (res) => {
      //    // console.log(JSON.parse(JSON.parse(res).body));
         
      //    this.campaignsData = JSON.parse(JSON.parse(res).body);
      //  })
      // this.commandService.common({ 'command': 'campaignList' })
      // this.snackConfigData = [true, 'wait', 'LOADING-START-MESSAGE'];
      this.campaignListService(1);

      this.snackConfigData = [true, "wait", "Campaigns is loading please wait..."];
   }
   // Campaign Listing Service
   campaignListService(sortByKey) {
      this.campaignsData = [];
      // this.readyStatus = false;
      this.campaignsService.getCampaignsList(sortByKey).subscribe(
         (res) => {
            setTimeout(() => {
              //  this.readyStatus = true;
               this.campaignsData = res;
               this.snackConfigData = [true, 500, 'LOADING-END-MESSAGE'];
              //  this.checkCampaignDataLoaded = true;

            }, 500)
         },
         (error) => {
            console.log(error);
         }
      )
   }

   campaignMenuVisible(ii, status) {
      if (status) {
         this.isCampaignMenuVisible[ii] = status;
      } else {
         this.isCampaignMenuVisible[ii] = status;
      }
   }

   changeCampaignStatusIn(sortByKey) {
      this.tabTypeSelected = sortByKey;
      if (this.readyStatus && sortByKey != null) {
         this.snackConfigData = [true, 'wait', 'LOADING-START-MESSAGE'];
         this.campaignListService(sortByKey);
      }
   }

   inSearchValue(value) {
      this.outSearchValue = value;
   }
}
