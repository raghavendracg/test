import { Component, OnInit } from '@angular/core';

export class QuickActionMenuClass {
   quickActionData = [
      {
         'status': 'Active',
         'statusCode': '1',
         'quickActionMenu': [
            { 'name': 'MANAGE-AGENTS', 'action': '' },
            { 'name': 'RECYCLE-CAMPAIGN', 'action': '' },
            {
               'name': 'CHANGE-STATUS', 'status':
               [
                  { 'name': 'PAUSED', 'action': '' },
                  { 'name': 'CLOSED', 'action': '' },
                  { 'name': 'DRAFT', 'action': '' },
                  { 'name': 'ARCHIVE', 'action': '' }
               ]
            },
            { 'name': 'ADD-CONTACTS', 'action': '' },
            { 'name': 'DUPLICATE-CAMPAIGN', 'action': '' },
            { 'name': 'MODIFY-CAMPAIGN-PRIORITY', 'action': '' },
            { 'name': 'DELETE', 'action': '' }
         ]
      },
      {
         'status': 'Draft',
         'statusCode': '2',
         'quickActionMenu': [
            { 'name': 'MANAGE-AGENTS', 'action': '' },
            {
               'name': 'CHANGE-STATUS', 'status':
               [
                  { 'name': 'ARCHIVE', 'action': '' },
                  { 'name': 'PAUSED', 'action': '' },
                  { 'name': 'CLOSED', 'action': '' },
                  { 'name': 'ARCHIVE', 'action': '' }
               ]
            },
            { 'name': 'ADD-CONTACTS', 'action': '' },
            { 'name': 'DUPLICATE-CAMPAIGN', 'action': '' },
            { 'name': 'MODIFY-CAMPAIGN-PRIORITY', 'action': '' },
            { 'name': 'DELETE', 'action': '' }
         ]
      },
      {
         'status': 'Closed',
         'statusCode': '0',
         'quickActionMenu': [
            { 'name': 'RECYCLE-CAMPAIGN', 'action': '' },
            {
               'name': 'CHANGE-STATUS', 'status':
               [
                  { 'name': 'ACTIVE', 'action': '' },
                  { 'name': 'PAUSED', 'action': '' },
                  { 'name': 'DRAFTS', 'action': '' },
                  { 'name': 'ARCHIVE', 'action': '' }
               ]
            },
            { 'name': 'DUPLICATE-CAMPAIGN', 'action': '' },
            { 'name': 'DELETE', 'action': '' }
         ]
      },
      {
         'status': 'Paused',
         'statusCode': '3',
         'quickActionMenu': [
            { 'name': 'MANAGE-AGENTS', 'action': '' },
            { 'name': 'RECYCLE-CAMPAIGN', 'action': '' },
            {
               'name': 'CHANGE-STATUS', 'status':
               [
                  { 'name': 'ACTIVE', 'action': '' },
                  { 'name': 'CLOSED', 'action': '' },
                  { 'name': 'DRAFTS', 'action': '' },
                  { 'name': 'ARCHIVE', 'action': '' }
               ]
            },
            { 'name': 'ADD-CONTACTS', 'action': '' },
            { 'name': 'DUPLICATE-CAMPAIGN', 'action': '' },
            { 'name': 'MODIFY-CAMPAIGN-PRIORITY', 'action': '' },
            { 'name': 'DELETE', 'action': '' }
         ]
      },
      {
         'status': 'ARCHIVE',
         'statusCode': '4',
         'quickActionMenu': [
            { 'name': 'DUPLICATE-CAMPAIGN', 'action': '' },
         ]
      }
   ]
}
