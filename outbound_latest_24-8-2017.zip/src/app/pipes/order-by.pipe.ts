import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
   name: 'odOrderBy'
})
export class OrderByPipe implements PipeTransform {

   transform(data: any, key: string): any {
      if (key === undefined || key === '') {
         return data;
      }
      const arr = key.split('-');
      const keyString = arr[0];   // string or column name to sort(name or age or date)
      const sortOrder = arr[1];   // asc or desc order
      const byVal = 1;

      data.sort((a: any, b: any) => {

         if (keyString === 'date') {

            const left = Number(new Date(a[keyString]));
            const right = Number(new Date(b[keyString]));

            return (sortOrder === 'asc') ? right - left : left - right;
         } else if (keyString === 'name') {

            if (a[keyString] < b[keyString]) {
               return (sortOrder === 'asc') ? -1 * byVal : 1 * byVal;
            } else if (a[keyString] > b[keyString]) {
               return (sortOrder === 'asc') ? 1 * byVal : -1 * byVal;
            } else {
               return 0;
            }
         } else if (keyString === 'age') {
            return (sortOrder === 'asc') ? a[keyString] - b[keyString] : b[keyString] - a[keyString];
         }

      });

      return data;
   }

}
