import { SearchFilterPipe } from './search-filter-campaigns-list.pipe';

describe('SearchFilterCampaignsListPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
