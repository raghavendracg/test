import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { WebsocketProvider } from '../websocket/websocketProvider.service';

@Injectable()
export class Resolver implements Resolve<any> {
   constructor(private websocketProvider: WebsocketProvider) {

   }
   resolve() {
      return new Promise((resolve) => {
         if (this.websocketProvider.isOpened) {
            resolve(true);
         } else {
            this.websocketProvider.onOpen((e) => {
               resolve(true);
            });
         }
      });
   }
}
