// Angular
import { Injectable } from '@angular/core';


/**
 * ErrorService
 * This class allows us to call command
 */
@Injectable()
export class ErrorService {

    className: string = 'ErrorService';
    commonErrorMsg: string = '';
    commandCode: any;
 

    //////////////////////////////////////
    // INIT
    //////////////////////////////////////

    /**
     *
     */
    public process(data) {
        console.error("[" + this.className + "] Error Service >>");
        console.error(data);    
    }



};
