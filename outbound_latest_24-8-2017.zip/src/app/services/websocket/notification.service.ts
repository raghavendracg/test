import { Injectable } from '@angular/core';
import { CommandService } from './command.service';
import { MessageService } from './message.service';

@Injectable()
export class NotificationService {


  constructor(
    // private commandService: CommandService
    private messageService: MessageService
  ) { }

  process(data) {
    // switch (data) {
    //   case 'cdc':
    //   console.log('received in notification');
    //   console.log(data);
    // }
    console.log('received in notification');
      console.log(data);
      // send data with command
      this.messageService.broadcast(data);
  }

}
