import { Injectable } from '@angular/core';
import { WebsocketProvider } from './websocketProvider.service';

// Models
import { WsRequestMessage } from '../../models/WsRequestMessage';

// Constants
import Commands from '../../constants/commands';

@Injectable()
export class CommandService {


    constructor(
        private websocketProvider: WebsocketProvider
    ) { }



    //////////////////////////////////////
    // INIT
    //////////////////////////////////////

    /**
     * Start connection in ws
     */
    public startConnection(url: string, reConnInterval: number, reConnTrial: number) {
        this.websocketProvider.onOpen((e) => {
            this.start();
        });

        this.websocketProvider.open(url, reConnInterval, reConnTrial);
    }

    /**
     * This method log on the user into the system
     */
    private start() {
        let request = new WsRequestMessage(Commands.START);

        this.websocketProvider.send(request);
    }

    common(command) {
        this.websocketProvider.send(command);
    }

}
