import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/filter'
import 'rxjs/add/operator/map'

type MessageCallback = (data: any) => void;

@Injectable()
export class MessageService {
  private handler = new Subject<any>();
  constructor() { }


  broadcast(data: any) {
    this.handler.next(data);
  }

  subscribe(id: string, callback: MessageCallback): Subscription {
    return this.handler
      // .filter(message => message.id === id)
      .map(message => message.data)
      .subscribe(callback);
  }

}
