import { Component, OnInit, Input } from '@angular/core';

@Component({
   selector: 'od-pagination',
   templateUrl: './pagination.component.html',
   styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {
   @Input() data;
   p = 1;
   collection: any[] = ['Testing Pagination 1', 'Testing Pagination 2', 'Testing Pagination 3'];
   constructor() {
      console.log(this.data);
   }

   ngOnInit() {
   }

}
