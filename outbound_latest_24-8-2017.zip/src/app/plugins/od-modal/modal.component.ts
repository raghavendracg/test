import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'od-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent implements OnInit {
  @Input() modalTitle;
  @Output() closeModalValue: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  closeModal() {
    this.closeModalValue.emit(1);
  }

}
