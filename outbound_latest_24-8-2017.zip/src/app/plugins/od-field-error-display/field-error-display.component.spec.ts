import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldErrorDisplay } from './field-error-display.component';

describe('odFieldErrorDisplay', () => {
  let component: FieldErrorDisplay;
  let fixture: ComponentFixture<FieldErrorDisplay>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldErrorDisplay ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldErrorDisplay);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
