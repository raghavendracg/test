import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TimeSlotSelectorComponent } from './time-slot-selector.component';

describe('TimeSlotSelectorComponent', () => {
  let component: TimeSlotSelectorComponent;
  let fixture: ComponentFixture<TimeSlotSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TimeSlotSelectorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeSlotSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
