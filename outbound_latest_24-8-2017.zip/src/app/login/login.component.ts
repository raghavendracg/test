import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';

@Component({
   selector: 'od-app-login',
   templateUrl: './login.component.html',
   styleUrls: ['./login.component.scss']
})

export class LoginComponent implements OnInit {
   loginModal: any = {};
   loading = false;
   returnUrl: string;
   langValue: string = localStorage.getItem('langValue');
   constructor(
      private route: ActivatedRoute,
      private router: Router,
      private translate: TranslateService
   ) { }

   ngOnInit() {
   }

   login() {
      this.loading = true;
      if (this.langValue) {
         // this.translate.setDefaultLang('fr');
         // let browserLang = this.translate.getBrowserLang();
         localStorage.setItem('langValue', this.langValue);
         this.translate.use(localStorage.getItem('langValue'))
      } else {
         this.translate.use('en');
      }
      this.router.navigateByUrl('/campaign/manage-campaign');
   }
}
