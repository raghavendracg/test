import { RouterModule, Routes, Resolve } from '@angular/router';
import { Resolver } from './services/resolver/resolver';
import { LoginComponent } from './login/login.component';
import { CampaignsListComponent } from './components/campaign-monitoring/campaigns-list/campaigns-list.component';

import { CampaignWizardComponent } from './components/campaign-wizard/campaign-wizard';
import { GeneralSettingsComponent } from './components/campaign-wizard/general-settings/general-settings.component';
import { DialingComponent } from './components/campaign-wizard/forms/dialing/dialing.component';
import { CallbackCycleComponent } from './components/campaign-wizard/forms/callback-cycle/callback-cycle.component';
import { CallReasonsComponent } from './components/campaign-wizard/forms/call-reasons/call-reasons.component';
export const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', component: CampaignsListComponent },
      { 
        path: 'manage-campaign', 
        component: CampaignsListComponent, 
        // resolve: { resolve: Resolver }  
      },
      {
        path: 'new', component: CampaignWizardComponent,
        children: [
          { path: '', component: GeneralSettingsComponent },
          { path: 'general-settings', component: GeneralSettingsComponent },
          { path: 'callback-cycle', component: CallbackCycleComponent },
          { path: 'dialing', component: DialingComponent },
          { path: 'call-reasons', component: CallReasonsComponent }
        ]
      }
    ]
  },
  { path: '', redirectTo: 'outbound',  pathMatch: 'full' }
];
