import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

// WebSocket
import { WebsocketProvider } from './services/websocket/websocketProvider.service';
import { CommandService } from './services/websocket/command.service';
import { NotificationService } from './services/websocket/notification.service';
import { MessageService } from './services/websocket/message.service';
import { ErrorService } from './services/error.service'
// End WebSocket

// Resolver
import { Resolver } from './services/resolver/resolver';

// i18n Translation
import { TranslateModule, TranslateLoader, TranslateService } from '@ngx-translate/core';
import {MissingTranslationHandler, MissingTranslationHandlerParams} from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { SnackbarComponent } from './plugins/od-snackbar/snackbar.component';
// for changing path of lang files.
export function createTranslateLoader(http: Http) {
  return new TranslateHttpLoader(http, 'assets/i18n/', '.json');
}
// Missing Translation Handler 
export class MissingTranslationKeys implements MissingTranslationHandler {
  handle(params: MissingTranslationHandlerParams) {
      console.error('Key Name: ' + params.key + '  is missing in i18n lang File. Please add the key.');
      return params.key;
  }
}
// end

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';

import { AppComponent } from './app.component'; // Main Component
import { LoginComponent } from './login/login.component';

import { NgxPaginationModule } from 'ngx-pagination'; // Boostrap Pagination

// Campaign Monitoring Components
import { CampaignsListComponent } from './components/campaign-monitoring/campaigns-list/campaigns-list.component';
import { SearchFilterComponent } from './components/campaign-monitoring/search-filter/search-filter.component';
import { CampaignNameHeaderComponent } from './components/campaign-wizard/campaign-name-header/campaign-name-header.component';

import { ProgressBarComponent } from './components/campaign-wizard/progress-bar/progress-bar.component';
import { PaginationComponent } from './plugins/od-pagination/pagination.component';
// end

// Campaign Wizard Components
import { CampaignWizardComponent } from './components/campaign-wizard/campaign-wizard';
import { GeneralSettingsComponent } from './components/campaign-wizard/general-settings/general-settings.component';
import { DialingComponent } from './components/campaign-wizard/forms/dialing/dialing.component';
import { CallbackCycleComponent } from './components/campaign-wizard/forms/callback-cycle/callback-cycle.component';
// end

// Header Component
import { SubHeaderComponent } from './header/sub-header/sub-header.component';
// end

// http services
import { CampaignsService } from './http-services/campaigns.service'; // Campaign Montioring Service
// end

// cookies
import { CookieService } from 'ngx-cookie-service';
// Pipes
import { SearchFilterPipe } from './pipes/search-filter-campaigns-list.pipe';
// end

// Routes
import { RouterModule, Routes, RouterLink } from '@angular/router';
import { routes } from './routes';
import { OrderByPipe } from './pipes/order-by.pipe';
import { InputSpinnerComponent } from './plugins/od-input-spinner/input-spinner.component';
import { CustomCheckboxComponent } from './plugins/od-custom-checkbox/custom-checkbox.component';
import { ModalComponent } from './plugins/od-modal/modal.component';
import { FieldErrorDisplay } from './plugins/od-field-error-display/field-error-display.component';
import { TimeSlotSelectorComponent } from './plugins/od-time-slot-selector/time-slot-selector.component';
// end

import { HotTableModule, HotTable } from 'ng2-handsontable';
import { DynamicHTMLModule } from 'ng-dynamic';

import { ApplicationHeaderComponent } from './header/application-header/application-header.component';
import { CallReasonsComponent } from './components/campaign-wizard/forms/call-reasons/call-reasons.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SubHeaderComponent,
    CampaignsListComponent,
    SearchFilterComponent,
    CampaignNameHeaderComponent,
    GeneralSettingsComponent,
    CallbackCycleComponent,
    CampaignWizardComponent,
    ProgressBarComponent,

    // Plugin Component
    SnackbarComponent,
    FieldErrorDisplay,
    PaginationComponent,

    // Pipes Declaration
    SearchFilterPipe,
    OrderByPipe,
    InputSpinnerComponent,
    CustomCheckboxComponent,
    DialingComponent,
    ModalComponent,
    TimeSlotSelectorComponent,
    ApplicationHeaderComponent,
    CallReasonsComponent
  ],
  // entryComponents: [
  //    ModalComponent
  // ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),

    // External Modules
    TranslateModule.forRoot({
      missingTranslationHandler: 
      {
        provide: MissingTranslationHandler, 
        useClass: MissingTranslationKeys
      },
      loader: {
        provide: TranslateLoader,
        useFactory: (createTranslateLoader),
        deps: [Http]
      }
    }),
    NgxPaginationModule,
    HotTableModule,
    DynamicHTMLModule.forRoot({
      components: [
        { component: CallbackCycleComponent, selector: 'od-callback-cycle' },
      ]
    })
  ],
  providers: [
    RouterLink,
    WebsocketProvider,
    CommandService,
    MessageService,
    NotificationService,
    Resolver,
    CampaignsService,
    HotTable,
    CookieService,
    ErrorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  myVertxCookie: string;

  constructor(
    private translate: TranslateService,
    private commandService: CommandService,
    private cookieService: CookieService
  ) {
    this.translate.addLangs(['en', 'fr']); // Defining the Language 
    this.translate.setDefaultLang('en'); // Sets Fallback Language

    if (!localStorage.getItem('langValue')) {
      localStorage.setItem('langValue', 'en');
    } else {
      this.translate.use(localStorage.getItem('langValue'));
    }

    // start websocket by passing cmd
    let socketPath = this.getCookie('socketPath');
    let wsReConnectionIntervals = this.getCookie('wsReConnectionIntervals');
    let wsReConnectionTrials = this.getCookie('wsReConnectionTrials');
    // this.startWebsocket(socketPath, +wsReConnectionIntervals, +wsReConnectionTrials);
    // this.startWebsocket('http://DIN16001084:8080/eventbus/', 5000, 5000);
  }

  startWebsocket(url: string, reConnInterval: number, reConnTrial: number) {
    // open websocket
    this.commandService.startConnection(url, reConnInterval, reConnTrial);
    // ODEmitterService.get('get-start').emit();
    this.myVertxCookie = this.getCookie('vertx-web.session');
  }

  getCookie(key: string) {
    return this.cookieService.get(key);
  }

}
