import { WsRequestMessage } from './WsRequestMessage';

export class WsResponseMessage extends WsRequestMessage {

    private responseDate: number;
    private response: number;
    private responseBody: string;

    public constructor() {
        super();
    }

    getResponseDate(): number {
        return this.responseDate;
    }

    setResponseDate(responseDate: number) {
        this.responseDate = responseDate;
    }

    getResponse(): number {
        return this.response;
    }

    setResponse(response: number) {
        this.response = response;
    }

    getResponseBody(): string {
        return this.responseBody;
    }

    setResponseBody(responseBody: string) {
        this.responseBody = responseBody;
    }
}
