import { UUID } from 'angular2-uuid';

export class WsMessage {

    private messageId: string;
    private uid: string;
    private sessionToken: string;
    private creationDate: number;
   
    private data = new Object();
   
    public constructor() {
        this.messageId = UUID.UUID();
        let timestamp = (new Date()).getTime();
        this.creationDate = timestamp;
    }

    getMessageId(): string {
        return this.messageId;
    }

    setMessageId(value: string) {
        this.messageId = value;
    }

    getUid(): string {
        return this.uid;
    }

    setUid(value: string) {
        this.uid = value;
    }

    getCreationDate(): number {
        return this.creationDate;
    }

    setCreationDate(value: number) {
        this.creationDate = value;
    }

    getSessionToken(): string {
        return this.sessionToken;
    }

    setSessionToken(sessionToken: string) {
        this.sessionToken = sessionToken;
    }
        
    getData (): Object {
       return this.data;
    }

    setData (value: Object){
        this.data = value;
    }
}
