import { WsMessage } from './WsMessage';

export class WsRequestMessage extends WsMessage {

    private command: string;

    // private body: string;

    public constructor(command?: string) {
        super();
        this.command = command;
    }

    getCommand(): string {
        return this.command;
    }

    setCommand(value: string) {
        this.command = value;
    }

}
