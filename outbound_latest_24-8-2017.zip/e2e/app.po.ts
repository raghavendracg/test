import { browser, by, element } from 'protractor';

export class OutboundCampaignPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('od-root')).getText();
  }
}
