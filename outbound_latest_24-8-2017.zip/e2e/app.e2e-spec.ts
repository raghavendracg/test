import { OutboundCampaignPage } from './app.po';

describe('outbound-campaign App', () => {
  let page: OutboundCampaignPage;

  beforeEach(() => {
    page = new OutboundCampaignPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    // expect(page.getParagraphText()).toEqual('');
  });
});
